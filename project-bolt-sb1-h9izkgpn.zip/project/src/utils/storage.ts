// Legacy storage functions - keeping for backward compatibility
// These now use Firebase instead of localStorage

import { Workout, NutritionDay, BodyMetric, BodyPhoto, AIConversation } from '../types';
import * as firebaseStorage from './firebaseStorage';

// Workout storage
export const saveWorkout = async (workout: Workout): Promise<void> => {
  return firebaseStorage.saveWorkout(workout);
};

export const getWorkouts = async (): Promise<Workout[]> => {
  return firebaseStorage.getWorkouts();
};

// Nutrition storage
export const saveNutritionDay = async (nutritionDay: NutritionDay): Promise<void> => {
  return firebaseStorage.saveNutritionDay(nutritionDay);
};

export const getNutritionDays = async (): Promise<NutritionDay[]> => {
  return firebaseStorage.getNutritionDays();
};

// Body metrics storage
export const saveBodyMetric = async (bodyMetric: BodyMetric): Promise<void> => {
  return firebaseStorage.saveBodyMetric(bodyMetric);
};

export const getBodyMetrics = async (): Promise<BodyMetric[]> => {
  return firebaseStorage.getBodyMetrics();
};

// Body photos storage
export const saveBodyPhoto = async (bodyPhoto: BodyPhoto): Promise<void> => {
  return firebaseStorage.saveBodyPhoto(bodyPhoto);
};

export const getBodyPhotos = async (): Promise<BodyPhoto[]> => {
  return firebaseStorage.getBodyPhotos();
};

// AI conversations storage
export const saveAIConversation = async (conversation: AIConversation): Promise<string> => {
  return firebaseStorage.saveAIConversation(conversation);
};

export const getAIConversations = async (): Promise<AIConversation[]> => {
  return firebaseStorage.getAIConversations();
};