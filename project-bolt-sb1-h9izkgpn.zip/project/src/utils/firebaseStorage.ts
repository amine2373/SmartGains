import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  query, 
  orderBy, 
  where,
  Timestamp 
} from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { db } from '../config/firebase';
import { Workout, NutritionDay, BodyMetric, BodyPhoto, AIConversation } from '../types';

// Get current user ID from Firebase Auth
const getUserId = (): string | null => {
  // Get the current user from Firebase Auth
  const auth = getAuth();
  const currentUser = auth.currentUser;
  
  if (currentUser) {
    return currentUser.uid;
  }
  
  // Fallback for demo purposes
  let userId = localStorage.getItem('demo_user_id');
  if (!userId) {
    userId = 'user_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('demo_user_id', userId);
  }
  return userId;
};

// Workout operations
export const saveWorkout = async (workout: Workout): Promise<void> => {
  try {
    const userId = getUserId();
    if (!userId) throw new Error('User not authenticated');

    const workoutData = {
      ...workout,
      userId,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };

    if (workout.id && workout.id !== Date.now().toString()) {
      // Update existing workout
      const workoutRef = doc(db, 'workouts', workout.id);
      await updateDoc(workoutRef, {
        ...workoutData,
        updatedAt: Timestamp.now()
      });
    } else {
      // Create new workout
      const docRef = await addDoc(collection(db, 'workouts'), workoutData);
      workout.id = docRef.id;
    }
  } catch (error) {
    console.error('Error saving workout:', error);
    throw error;
  }
};

export const getWorkouts = async (): Promise<Workout[]> => {
  try {
    const userId = getUserId();
    if (!userId) return [];

    const q = query(
      collection(db, 'workouts'),
      where('userId', '==', userId)
    );
    
    const querySnapshot = await getDocs(q);
    const workouts = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Workout[];
    
    // Sort by createdAt in JavaScript instead of Firestore
    return workouts.sort((a, b) => {
      const aTime = a.createdAt?.toMillis?.() || new Date(a.date).getTime();
      const bTime = b.createdAt?.toMillis?.() || new Date(b.date).getTime();
      return bTime - aTime; // Descending order (newest first)
    });
  } catch (error) {
    console.error('Error getting workouts:', error);
    return [];
  }
};

export const deleteWorkout = async (workoutId: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, 'workouts', workoutId));
  } catch (error) {
    console.error('Error deleting workout:', error);
    throw error;
  }
};

// Nutrition operations
export const saveNutritionDay = async (nutritionDay: NutritionDay): Promise<string> => {
  try {
    const userId = getUserId();
    if (!userId) throw new Error('User not authenticated');

    const nutritionData = {
      ...nutritionDay,
      userId,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };

    if (nutritionDay.id && nutritionDay.id.trim() !== '') {
      // Update existing nutrition day
      const nutritionRef = doc(db, 'nutrition', nutritionDay.id);
      await updateDoc(nutritionRef, {
        ...nutritionData,
        updatedAt: Timestamp.now()
      });
      return nutritionDay.id;
    } else {
      // Create new nutrition day
      const docRef = await addDoc(collection(db, 'nutrition'), nutritionData);
      return docRef.id;
    }
  } catch (error) {
    console.error('Error saving nutrition day:', error);
    throw error;
  }
};

export const getNutritionDays = async (): Promise<NutritionDay[]> => {
  try {
    const userId = getUserId();
    if (!userId) return [];

    const q = query(
      collection(db, 'nutrition'),
      where('userId', '==', userId)
    );
    
    const querySnapshot = await getDocs(q);
    const nutritionDays = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as NutritionDay[];
    
    // Sort by createdAt in JavaScript instead of Firestore
    return nutritionDays.sort((a, b) => {
      const aTime = a.createdAt?.toMillis?.() || new Date(a.date).getTime();
      const bTime = b.createdAt?.toMillis?.() || new Date(b.date).getTime();
      return bTime - aTime; // Descending order (newest first)
    });
  } catch (error) {
    console.error('Error getting nutrition days:', error);
    return [];
  }
};

// Body metrics operations
export const saveBodyMetric = async (bodyMetric: BodyMetric): Promise<void> => {
  try {
    const userId = getUserId();
    if (!userId) throw new Error('User not authenticated');

    const metricData = {
      ...bodyMetric,
      userId,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };

    if (bodyMetric.id && bodyMetric.id !== Date.now().toString()) {
      // Update existing metric
      const metricRef = doc(db, 'bodyMetrics', bodyMetric.id);
      await updateDoc(metricRef, {
        ...metricData,
        updatedAt: Timestamp.now()
      });
    } else {
      // Create new metric
      const docRef = await addDoc(collection(db, 'bodyMetrics'), metricData);
      bodyMetric.id = docRef.id;
    }
  } catch (error) {
    console.error('Error saving body metric:', error);
    throw error;
  }
};

export const getBodyMetrics = async (): Promise<BodyMetric[]> => {
  try {
    const userId = getUserId();
    if (!userId) return [];

    const q = query(
      collection(db, 'bodyMetrics'),
      where('userId', '==', userId)
    );
    
    const querySnapshot = await getDocs(q);
    const bodyMetrics = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as BodyMetric[];
    
    // Sort by createdAt in JavaScript instead of Firestore
    return bodyMetrics.sort((a, b) => {
      const aTime = a.createdAt?.toMillis?.() || new Date(a.date).getTime();
      const bTime = b.createdAt?.toMillis?.() || new Date(b.date).getTime();
      return aTime - bTime; // Ascending order (oldest first)
    });
  } catch (error) {
    console.error('Error getting body metrics:', error);
    return [];
  }
};

// Body photos operations
export const saveBodyPhoto = async (bodyPhoto: BodyPhoto): Promise<void> => {
  try {
    const userId = getUserId();
    if (!userId) throw new Error('User not authenticated');

    const photoData = {
      ...bodyPhoto,
      userId,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };

    if (bodyPhoto.id && bodyPhoto.id !== Date.now().toString()) {
      // Update existing photo
      const photoRef = doc(db, 'bodyPhotos', bodyPhoto.id);
      await updateDoc(photoRef, {
        ...photoData,
        updatedAt: Timestamp.now()
      });
    } else {
      // Create new photo
      const docRef = await addDoc(collection(db, 'bodyPhotos'), photoData);
      bodyPhoto.id = docRef.id;
    }
  } catch (error) {
    console.error('Error saving body photo:', error);
    throw error;
  }
};

export const getBodyPhotos = async (): Promise<BodyPhoto[]> => {
  try {
    const userId = getUserId();
    if (!userId) return [];

    const q = query(
      collection(db, 'bodyPhotos'),
      where('userId', '==', userId)
    );
    
    const querySnapshot = await getDocs(q);
    const bodyPhotos = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as BodyPhoto[];
    
    // Sort by createdAt in JavaScript instead of Firestore
    return bodyPhotos.sort((a, b) => {
      const aTime = a.createdAt?.toMillis?.() || new Date(a.date).getTime();
      const bTime = b.createdAt?.toMillis?.() || new Date(b.date).getTime();
      return bTime - aTime; // Descending order (newest first)
    });
  } catch (error) {
    console.error('Error getting body photos:', error);
    return [];
  }
};

// AI conversations operations
export const saveAIConversation = async (conversation: AIConversation): Promise<string> => {
  try {
    const userId = getUserId();
    if (!userId) throw new Error('User not authenticated');

    const conversationData = {
      ...conversation,
      userId,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };

    if (conversation.id && conversation.id.trim() !== '') {
      // Update existing conversation
      const conversationRef = doc(db, 'aiConversations', conversation.id);
      await updateDoc(conversationRef, {
        ...conversationData,
        updatedAt: Timestamp.now()
      });
      return conversation.id;
    } else {
      // Create new conversation
      const docRef = await addDoc(collection(db, 'aiConversations'), conversationData);
      return docRef.id;
    }
  } catch (error) {
    console.error('Error saving AI conversation:', error);
    throw error;
  }
};

export const getAIConversations = async (): Promise<AIConversation[]> => {
  try {
    const userId = getUserId();
    if (!userId) return [];

    const q = query(
      collection(db, 'aiConversations'),
      where('userId', '==', userId)
    );
    
    const querySnapshot = await getDocs(q);
    const conversations = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as AIConversation[];
    
    // Sort by createdAt in JavaScript instead of Firestore
    return conversations.sort((a, b) => {
      const aTime = a.createdAt?.toMillis?.() || new Date(a.date || 0).getTime();
      const bTime = b.createdAt?.toMillis?.() || new Date(b.date || 0).getTime();
      return bTime - aTime; // Descending order (newest first)
    });
  } catch (error) {
    console.error('Error getting AI conversations:', error);
    return [];
  }
};

export const deleteAIConversation = async (conversationId: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, 'aiConversations', conversationId));
  } catch (error) {
    console.error('Error deleting AI conversation:', error);
    throw error;
  }
};