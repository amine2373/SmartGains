import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBSgcucVjiyDZ-pZ76BD-tnNfTpqC7h2EI",
  authDomain: "smart-gains-2.firebaseapp.com",
  projectId: "smart-gains-2",
  storageBucket: "smart-gains-2.firebasestorage.app",
  messagingSenderId: "447175552200",
  appId: "1:447175552200:web:93a5a762078b045ff449fd",
  measurementId: "G-XYE508BZV7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

export default app;