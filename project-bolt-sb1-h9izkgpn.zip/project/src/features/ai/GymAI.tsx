import React, { useState, useEffect, useRef } from 'react';
import { Send, Save, Trash2, User, Bot as BotIcon, Menu, X } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { AIConversation, AIMessage } from '../../types';
import { getAIConversations, saveAIConversation } from '../../utils/storage';
import { deleteAIConversation } from '../../utils/firebaseStorage';

const GymAI: React.FC = () => {
  const { t, language } = useLanguage();
  const [conversations, setConversations] = useState<AIConversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [showSidebar, setShowSidebar] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const loadConversations = async () => {
      try {
        const loadedConversations = await getAIConversations();
        setConversations(loadedConversations);
        
        if (loadedConversations.length > 0) {
          setActiveConversationId(loadedConversations[0].id);
        } else {
          await createNewConversation();
        }
      } catch (error) {
        console.error('Error loading conversations:', error);
      } finally {
        setLoadingConversations(false);
      }
    };

    loadConversations();
  }, []);
  
  useEffect(() => {
    scrollToBottom();
  }, [activeConversationId, conversations]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const createNewConversation = async () => {
    const newConversation: AIConversation = {
      id: '', // Initialize as empty string for new conversations
      title: 'New Conversation',
      messages: [],
      createdAt: new Date().toISOString()
    };
    
    try {
      const conversationId = await saveAIConversation(newConversation);
      newConversation.id = conversationId; // Assign the Firestore-generated ID
      setConversations([newConversation, ...conversations]);
      setActiveConversationId(newConversation.id);
      setShowSidebar(false); // Close sidebar on mobile after creating
    } catch (error) {
      console.error('Error creating conversation:', error);
    }
  };
  
  const deleteConversation = async (id: string) => {
    try {
      await deleteAIConversation(id);
      const updatedConversations = conversations.filter(conv => conv.id !== id);
      setConversations(updatedConversations);
      
      if (activeConversationId === id) {
        if (updatedConversations.length > 0) {
          setActiveConversationId(updatedConversations[0].id);
        } else {
          await createNewConversation();
        }
      }
    } catch (error) {
      console.error('Error deleting conversation:', error);
    }
  };
  
  const sendMessage = async () => {
    if (!inputMessage.trim() || !activeConversationId) return;
    
    const userMessage: AIMessage = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date().toISOString()
    };
    
    const updatedConversations = conversations.map(conv => {
      if (conv.id === activeConversationId) {
        return {
          ...conv,
          messages: [...conv.messages, userMessage],
          title: conv.messages.length === 0 ? truncateTitle(inputMessage, 30) : conv.title
        };
      }
      return conv;
    });
    
    setConversations(updatedConversations);
    setInputMessage('');
    setLoading(true);
    
    const activeConversation = updatedConversations.find(conv => conv.id === activeConversationId);
    if (activeConversation) {
      try {
        await saveAIConversation(activeConversation);
      } catch (error) {
        console.error('Error saving conversation:', error);
      }
    }

    try {
      // Create language-specific prompt
      const getPromptForLanguage = () => {
        switch (language) {
          case 'es':
            return `Eres un experto en fitness y nutrición. Debes responder de manera DETALLADA pero ESTRICTAMENTE ENFOCADA en la pregunta planteada.

REGLAS IMPORTANTES:
- Responde ÚNICAMENTE lo que se pregunta
- Da detalles profundos pero mantente en el tema
- No te desvíes a otros temas no mencionados
- Proporciona explicaciones completas pero enfocadas
- Usa 150-250 palabras para ser detallado sin desviarte
- Explica el "por qué" pero solo en relación con la pregunta
- Da ejemplos concretos relacionados con el tema solicitado

PREGUNTA: ${inputMessage}

Responde en detalle pero mantente estrictamente dentro del alcance de esta pregunta específica.`;

          case 'ar':
            return `أنت خبير في اللياقة البدنية والتغذية. يجب أن تجيب بطريقة مفصلة ولكن مركزة بدقة على السؤال المطروح.

القواعد المهمة:
- أجب فقط على ما هو مطلوب في السؤال
- قدم تفاصيل عميقة لكن ابق في الموضوع
- لا تنحرف إلى مواضيع أخرى غير مذكورة
- قدم شروحات كاملة لكن مركزة
- استخدم 150-250 كلمة لتكون مفصلاً دون الخروج عن الموضوع
- اشرح "لماذا" لكن فقط فيما يتعلق بالسؤال
- قدم أمثلة ملموسة متعلقة بالموضوع المطلوب

السؤال: ${inputMessage}

أجب بالتفصيل لكن ابق بدقة ضمن نطاق هذا السؤال المحدد.`;

          case 'fr':
            return `Tu es un expert en fitness et nutrition. Tu dois répondre de manière DÉTAILLÉE mais STRICTEMENT CIBLÉE sur la question posée.

RÈGLES IMPORTANTES:
- Réponds UNIQUEMENT à ce qui est demandé dans la question
- Donne des détails approfondis mais reste dans le sujet
- Ne dévie pas vers d'autres sujets non mentionnés
- Fournis des explications complètes mais focalisées
- Utilise 150-250 mots pour être détaillé sans déborder
- Explique le "pourquoi" mais seulement en rapport avec la question
- Donne des exemples concrets liés au sujet demandé

QUESTION: ${inputMessage}

Réponds de manière détaillée mais reste strictement dans le cadre de cette question spécifique.`;

          case 'de':
            return `Du bist ein Experte für Fitness und Ernährung. Du musst DETAILLIERT aber STRIKT FOKUSSIERT auf die gestellte Frage antworten.

WICHTIGE REGELN:
- Antworte NUR auf das, was in der Frage gefragt wird
- Gib tiefgreifende Details, aber bleibe beim Thema
- Weiche nicht zu anderen nicht erwähnten Themen ab
- Liefere vollständige aber fokussierte Erklärungen
- Verwende 150-250 Wörter, um detailliert zu sein, ohne abzuschweifen
- Erkläre das "Warum", aber nur in Bezug auf die Frage
- Gib konkrete Beispiele zum angefragten Thema

FRAGE: ${inputMessage}

Antworte detailliert, aber bleibe strikt im Rahmen dieser spezifischen Frage.`;

          default: // English
            return `You are a fitness and nutrition expert. You must respond in a DETAILED but STRICTLY FOCUSED manner on the question asked.

IMPORTANT RULES:
- Answer ONLY what is asked in the question
- Give in-depth details but stay on topic
- Do not deviate to other unmentioned subjects
- Provide complete explanations but focused
- Use 150-250 words to be detailed without going off-topic
- Explain the "why" but only in relation to the question asked
- Give concrete examples related to the requested topic

QUESTION: ${inputMessage}

Respond in detail but stay strictly within the scope of this specific question.`;
        }
      };

      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=AIzaSyCY0a_3v15jDMjiA1epfjKLBzBPCHvsjRw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: getPromptForLanguage()
            }]
          }],
          generationConfig: {
            temperature: 0.3,
            topK: 30,
            topP: 0.8,
            maxOutputTokens: 400,
          }
        })
      });

      const data = await response.json();
      let aiResponse = t('ai.cannot_answer');

      if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
        aiResponse = data.candidates[0].content.parts[0].text;
      } else if (data.error) {
        aiResponse = `Error: ${data.error.message || 'Unable to process your request'}`;
      }

      const responseMessage: AIMessage = {
        id: Date.now().toString(),
        content: aiResponse,
        sender: 'ai',
        timestamp: new Date().toISOString()
      };
      
      const conversationsWithResponse = conversations.map(conv => {
        if (conv.id === activeConversationId) {
          const updatedConv = {
            ...conv,
            messages: [...conv.messages, userMessage, responseMessage]
          };
          saveAIConversation(updatedConv).catch(error => {
            console.error('Error saving conversation with response:', error);
          });
          return updatedConv;
        }
        return conv;
      });
      
      setConversations(conversationsWithResponse);
    } catch (error) {
      console.error('Error calling Gemini API:', error);
      const errorMessage: AIMessage = {
        id: Date.now().toString(),
        content: t('ai.connection_error'),
        sender: 'ai',
        timestamp: new Date().toISOString()
      };

      const conversationsWithError = conversations.map(conv => {
        if (conv.id === activeConversationId) {
          const updatedConv = {
            ...conv,
            messages: [...conv.messages, userMessage, errorMessage]
          };
          saveAIConversation(updatedConv).catch(error => {
            console.error('Error saving conversation with error:', error);
          });
          return updatedConv;
        }
        return conv;
      });

      setConversations(conversationsWithError);
    } finally {
      setLoading(false);
    }
  };
  
  const truncateTitle = (text: string, maxLength: number): string => {
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  };
  
  const formatTimestamp = (timestamp: string): string => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const activeConversation = conversations.find(conv => conv.id === activeConversationId);

  if (loadingConversations) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
      </div>
    );
  }
  
  return (
    <div className="h-[calc(100vh-220px)] flex relative">
      {/* Mobile menu button */}
      <button
        onClick={() => setShowSidebar(!showSidebar)}
        className="md:hidden fixed top-4 left-4 z-50 p-2 bg-gray-900 rounded-md border border-gray-800"
      >
        {showSidebar ? <X className="h-5 w-5 text-white" /> : <Menu className="h-5 w-5 text-white" />}
      </button>

      {/* Sidebar overlay for mobile */}
      {showSidebar && (
        <div 
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setShowSidebar(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`
        ${showSidebar ? 'translate-x-0' : '-translate-x-full'} 
        md:translate-x-0 
        fixed md:relative 
        z-40 md:z-auto
        w-64 md:w-64 
        bg-gray-900 border-r border-gray-800 
        flex flex-col 
        transition-transform duration-300 ease-in-out
        h-full
      `}>
        <div className="p-4 border-b border-gray-800 mt-12 md:mt-0">
          <button
            onClick={createNewConversation}
            className="w-full px-4 py-2 bg-orange-500 rounded-md hover:bg-orange-600 transition-colors text-white flex items-center justify-center gap-2"
          >
            <BotIcon className="h-4 w-4" />
            <span className="text-sm">{t('ai.new_conversation')}</span>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2">
          {conversations.map(conversation => (
            <div
              key={conversation.id}
              onClick={() => {
                setActiveConversationId(conversation.id);
                setShowSidebar(false); // Close sidebar on mobile when selecting conversation
              }}
              className={`p-3 rounded-md mb-1 cursor-pointer flex justify-between items-center group ${
                activeConversationId === conversation.id
                  ? 'bg-gray-800'
                  : 'hover:bg-gray-800'
              }`}
            >
              <div className="overflow-hidden flex-1 mr-2">
                <p className="text-sm text-white truncate">{conversation.title}</p>
                <p className="text-xs text-gray-500 truncate">
                  {new Date(conversation.createdAt).toLocaleDateString()}
                </p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteConversation(conversation.id);
                }}
                className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-500 transition-opacity flex-shrink-0"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
      
      {/* Main chat area */}
      <div className="flex-1 flex flex-col bg-black min-w-0">
        {activeConversation ? (
          <>
            <div className="p-4 border-b border-gray-800 ml-12 md:ml-0">
              <h3 className="text-lg font-medium text-white truncate">{activeConversation.title}</h3>
              <p className="text-xs text-gray-400 mt-1">
                {t('ai.subtitle')}
              </p>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {activeConversation.messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center px-4">
                  <BotIcon className="h-16 w-16 text-orange-500 mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">{t('ai.title')}</h3>
                  <div className="text-gray-400 max-w-md space-y-2">
                    <p className="font-medium">
                      {t('ai.ask_questions')}
                    </p>
                    <ul className="text-sm space-y-1 text-left">
                      <li>• {t('ai.exercise_techniques')}</li>
                      <li>• {t('ai.nutrition_advice')}</li>
                      <li>• {t('ai.training_programs')}</li>
                      <li>• {t('ai.recovery_injuries')}</li>
                      <li>• {t('ai.supplementation')}</li>
                    </ul>
                    <p className="text-xs text-gray-500 mt-3">
                      {t('ai.detailed_response')}
                    </p>
                  </div>
                </div>
              ) : (
                activeConversation.messages.map(message => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[85%] sm:max-w-[80%] rounded-lg p-3 ${
                        message.sender === 'user'
                          ? 'bg-orange-600 text-white rounded-tr-none'
                          : 'bg-gray-800 text-white rounded-tl-none'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {message.sender === 'user' ? (
                          <>
                            <span className="text-xs font-medium">{t('ai.you')}</span>
                            <User className="h-3 w-3" />
                          </>
                        ) : (
                          <>
                            <span className="text-xs font-medium">SmartAI</span>
                            <BotIcon className="h-3 w-3" />
                          </>
                        )}
                        <span className="text-xs opacity-70">{formatTimestamp(message.timestamp)}</span>
                      </div>
                      <div className="text-sm whitespace-pre-wrap leading-relaxed break-words">
                        {message.content}
                      </div>
                    </div>
                  </div>
                ))
              )}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-gray-800 text-white rounded-lg rounded-tl-none p-3 max-w-[85%] sm:max-w-[80%]">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium">SmartAI</span>
                      <BotIcon className="h-3 w-3" />
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-orange-500"></div>
                      <span className="text-sm">{t('ai.focused_analysis')}</span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
            
            <div className="p-4 border-t border-gray-800">
              <div className="flex items-end gap-2">
                <textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                  placeholder={t('ai.placeholder')}
                  className="flex-1 bg-gray-900 border border-gray-700 rounded-md px-4 py-2 text-white focus:border-orange-500 focus:outline-none resize-none min-h-[40px] max-h-32"
                  disabled={loading}
                  rows={1}
                  style={{ 
                    height: 'auto',
                    minHeight: '40px'
                  }}
                  onInput={(e) => {
                    const target = e.target as HTMLTextAreaElement;
                    target.style.height = 'auto';
                    target.style.height = Math.min(target.scrollHeight, 128) + 'px';
                  }}
                />
                <button
                  onClick={sendMessage}
                  disabled={loading || !inputMessage.trim()}
                  className={`p-2 rounded-md flex-shrink-0 ${
                    loading || !inputMessage.trim()
                      ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                      : 'bg-orange-500 text-white hover:bg-orange-600'
                  } transition-colors`}
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-1 px-1">
                {t('ai.be_specific')}
              </p>
            </div>
          </>
        ) : (
          <div className="h-full flex items-center justify-center">
            <p className="text-gray-500">{t('ai.select_conversation')}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default GymAI;