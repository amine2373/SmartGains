import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, RotateCcw } from 'lucide-react';

interface TimerModalProps {
  onClose: () => void;
}

const TimerModal: React.FC<TimerModalProps> = ({ onClose }) => {
  const [seconds, setSeconds] = useState(60);
  const [isActive, setIsActive] = useState(false);
  const [inputMinutes, setInputMinutes] = useState('1');
  const [inputSeconds, setInputSeconds] = useState('0');
  const intervalRef = useRef<number | null>(null);
  
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);
  
  const startTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    
    setIsActive(true);
    intervalRef.current = window.setInterval(() => {
      setSeconds(prevSeconds => {
        if (prevSeconds <= 1) {
          clearInterval(intervalRef.current!);
          setIsActive(false);
          return 0;
        }
        return prevSeconds - 1;
      });
    }, 1000);
  };
  
  const pauseTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsActive(false);
  };
  
  const resetTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsActive(false);
    const mins = parseInt(inputMinutes) || 0;
    const secs = parseInt(inputSeconds) || 0;
    setSeconds(mins * 60 + secs);
  };
  
  const setCustomTime = () => {
    const mins = parseInt(inputMinutes) || 0;
    const secs = parseInt(inputSeconds) || 0;
    setSeconds(mins * 60 + secs);
  };
  
  const formatTime = (totalSeconds: number) => {
    const minutes = Math.floor(totalSeconds / 60);
    const remainingSeconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  const progress = seconds / (parseInt(inputMinutes) * 60 + parseInt(inputSeconds) || 60) * 100;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-xl max-w-md w-full border border-gray-800 shadow-lg">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-white">Rest Timer</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="relative h-48 w-48 mx-auto mb-6">
            <div className="absolute inset-0 rounded-full border-8 border-gray-800"></div>
            <div 
              className="absolute inset-0 rounded-full border-8 border-orange-500 transition-all duration-500"
              style={{ 
                clipPath: `polygon(50% 50%, 50% 0%, ${progress <= 25 ? 50 + progress * 2 : 100}% 0%, ${progress <= 50 ? 100 : 100}% ${progress <= 50 ? progress * 2 - 50 : 100}%, ${progress <= 75 ? 100 : 100 - (progress - 75) * 2}% 100%, ${progress <= 100 ? 50 - (progress - 75) * 2 : 0}% 100%, ${progress <= 25 ? 0 : 0}% ${progress <= 50 ? 0 : 100 - (progress - 50) * 2}%, ${progress <= 25 ? 0 : 50 - progress * 2 + 50}% 0%)` 
              }}
            ></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-4xl font-bold text-white">{formatTime(seconds)}</span>
            </div>
          </div>
          
          <div className="flex justify-center space-x-4 mb-6">
            {isActive ? (
              <button 
                onClick={pauseTimer}
                className="flex items-center justify-center w-12 h-12 rounded-full bg-orange-500 hover:bg-orange-600 transition-colors"
              >
                <Pause className="h-5 w-5 text-white" />
              </button>
            ) : (
              <button 
                onClick={startTimer}
                className="flex items-center justify-center w-12 h-12 rounded-full bg-orange-500 hover:bg-orange-600 transition-colors"
              >
                <Play className="h-5 w-5 text-white" />
              </button>
            )}
            
            <button 
              onClick={resetTimer}
              className="flex items-center justify-center w-12 h-12 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
            >
              <RotateCcw className="h-5 w-5 text-white" />
            </button>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Minutes</label>
              <input
                type="number"
                min="0"
                value={inputMinutes}
                onChange={(e) => setInputMinutes(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Seconds</label>
              <input
                type="number"
                min="0"
                max="59"
                value={inputSeconds}
                onChange={(e) => setInputSeconds(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
              />
            </div>
          </div>
          
          <button
            onClick={setCustomTime}
            className="w-full mt-4 px-4 py-2 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors text-white"
          >
            Set Time
          </button>
        </div>
      </div>
    </div>
  );
};

export default TimerModal;