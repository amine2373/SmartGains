import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, X, RefreshCw } from 'lucide-react';
import { getWorkouts } from '../../utils/storage';
import { Workout } from '../../types';

interface WorkoutCalendarProps {
  onClose: () => void;
  workouts?: Workout[];
  onRefresh?: () => void;
}

const WorkoutCalendar: React.FC<WorkoutCalendarProps> = ({ onClose, workouts: propWorkouts, onRefresh }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [workouts, setWorkouts] = useState<Workout[]>(propWorkouts || []);
  const [workoutDays, setWorkoutDays] = useState<string[]>([]);
  const [loading, setLoading] = useState(!propWorkouts);
  
  useEffect(() => {
    if (propWorkouts) {
      setWorkouts(propWorkouts);
      updateWorkoutDays(propWorkouts);
      setLoading(false);
    } else {
      loadWorkouts();
    }
  }, [propWorkouts]);

  const loadWorkouts = async () => {
    setLoading(true);
    try {
      const allWorkouts = await getWorkouts();
      setWorkouts(allWorkouts);
      updateWorkoutDays(allWorkouts);
    } catch (error) {
      console.error('Error loading workouts:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateWorkoutDays = (workoutList: Workout[]) => {
    const days = workoutList.map(workout => {
      const date = new Date(workout.date);
      return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
    });
    setWorkoutDays([...new Set(days)]);
  };

  const handleRefresh = async () => {
    if (onRefresh) {
      onRefresh();
    } else {
      await loadWorkouts();
    }
  };
  
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };
  
  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };
  
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    setSelectedDate(null);
  };
  
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    setSelectedDate(null);
  };
  
  const renderCalendar = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-10"></div>);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const dateString = `${year}-${month}-${day}`;
      const hasWorkout = workoutDays.includes(dateString);
      
      const isSelected = selectedDate 
        ? day === selectedDate.getDate() && 
          month === selectedDate.getMonth() && 
          year === selectedDate.getFullYear()
        : false;
        
      days.push(
        <div 
          key={`day-${day}`}
          onClick={() => setSelectedDate(date)}
          className={`h-10 flex items-center justify-center rounded-full cursor-pointer transition-colors ${
            isSelected 
              ? 'bg-orange-500 text-white'
              : hasWorkout 
                ? 'bg-gray-800 text-white hover:bg-gray-700' 
                : 'text-gray-400 hover:bg-gray-800'
          }`}
        >
          {day}
        </div>
      );
    }
    
    return days;
  };
  
  const getSelectedDateWorkouts = () => {
    if (!selectedDate) return [];
    
    return workouts.filter(workout => {
      const workoutDate = new Date(workout.date);
      return workoutDate.getDate() === selectedDate.getDate() && 
             workoutDate.getMonth() === selectedDate.getMonth() && 
             workoutDate.getFullYear() === selectedDate.getFullYear();
    });
  };
  
  const selectedWorkouts = getSelectedDateWorkouts();
  
  if (loading) {
    return (
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-white">Workout History</h3>
        <div className="flex gap-2">
          <button 
            onClick={handleRefresh} 
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors"
            title="Refresh workouts"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      <div className="calendar mb-6">
        <div className="flex justify-between items-center mb-4">
          <button onClick={prevMonth} className="p-1 hover:bg-gray-800 rounded">
            <ArrowLeft className="h-5 w-5 text-gray-400" />
          </button>
          
          <h4 className="text-lg font-medium text-white">
            {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
          </h4>
          
          <button onClick={nextMonth} className="p-1 hover:bg-gray-800 rounded">
            <ArrowRight className="h-5 w-5 text-gray-400" />
          </button>
        </div>
        
        <div className="grid grid-cols-7 gap-1 mb-1">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-center text-sm font-medium text-gray-500">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {renderCalendar()}
        </div>
      </div>

      {/* Workout count indicator */}
      <div className="mb-4 text-center">
        <p className="text-sm text-gray-400">
          Total workouts: <span className="text-orange-500 font-semibold">{workouts.length}</span>
        </p>
      </div>
      
      {selectedDate && (
        <div className="selected-date">
          <h4 className="text-lg font-medium text-white mb-3">
            {selectedDate.toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </h4>
          
          {selectedWorkouts.length > 0 ? (
            <div className="space-y-4">
              {selectedWorkouts.map(workout => (
                <div key={workout.id} className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                  <h5 className="text-white font-medium mb-2">{workout.name}</h5>
                  <p className="text-xs text-gray-500 mb-3">
                    {new Date(workout.date).toLocaleTimeString('en-US', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                  
                  <div className="space-y-3">
                    {workout.exercises.map(exercise => (
                      <div key={exercise.id} className="border-t border-gray-700 pt-2">
                        <p className="text-orange-400 font-medium">{exercise.name}</p>
                        
                        <div className="grid grid-cols-12 gap-2 text-sm text-gray-300 mt-1">
                          <div className="col-span-2">Set</div>
                          <div className="col-span-5">Reps</div>
                          <div className="col-span-5">Weight (kg)</div>
                        </div>
                        
                        {exercise.sets.map((set, index) => (
                          <div key={index} className="grid grid-cols-12 gap-2 text-sm text-gray-400">
                            <div className="col-span-2">{index + 1}</div>
                            <div className="col-span-5">{set.reps}</div>
                            <div className="col-span-5">{set.weight}</div>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400">No workouts on this day.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default WorkoutCalendar;