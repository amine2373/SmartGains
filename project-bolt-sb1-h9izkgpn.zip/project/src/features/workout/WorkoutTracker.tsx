import React, { useState, useEffect } from 'react';
import { Calendar, Plus, Play, Pause, XCircle } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import WorkoutCalendar from './WorkoutCalendar';
import TimerModal from './TimerModal';
import { Exercise, Workout } from '../../types';
import { saveWorkout, getWorkouts } from '../../utils/storage';

const WorkoutTracker: React.FC = () => {
  const { t } = useLanguage();
  const [showCalendar, setShowCalendar] = useState(false);
  const [showTimer, setShowTimer] = useState(false);
  const [loading, setLoading] = useState(false);
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [currentWorkout, setCurrentWorkout] = useState<Workout>({
    id: Date.now().toString(),
    date: new Date().toISOString(),
    name: t('workout.my_workout'),
    exercises: []
  });

  // Load workouts when component mounts
  useEffect(() => {
    const loadWorkouts = async () => {
      try {
        const loadedWorkouts = await getWorkouts();
        setWorkouts(loadedWorkouts);
      } catch (error) {
        console.error('Error loading workouts:', error);
      }
    };

    loadWorkouts();
  }, []);

  const addExercise = () => {
    const newExercise: Exercise = {
      id: Date.now().toString(),
      name: '',
      sets: [{ reps: 0, weight: 0 }]
    };
    
    setCurrentWorkout({
      ...currentWorkout,
      exercises: [...currentWorkout.exercises, newExercise]
    });
  };

  const updateExerciseName = (id: string, name: string) => {
    setCurrentWorkout({
      ...currentWorkout,
      exercises: currentWorkout.exercises.map(exercise => 
        exercise.id === id ? { ...exercise, name } : exercise
      )
    });
  };

  const updateSet = (exerciseId: string, setIndex: number, reps: number, weight: number) => {
    setCurrentWorkout({
      ...currentWorkout,
      exercises: currentWorkout.exercises.map(exercise => 
        exercise.id === exerciseId 
          ? { 
              ...exercise, 
              sets: exercise.sets.map((set, idx) => 
                idx === setIndex ? { reps, weight } : set
              ) 
            } 
          : exercise
      )
    });
  };

  const addSet = (exerciseId: string) => {
    setCurrentWorkout({
      ...currentWorkout,
      exercises: currentWorkout.exercises.map(exercise => 
        exercise.id === exerciseId 
          ? { ...exercise, sets: [...exercise.sets, { reps: 0, weight: 0 }] } 
          : exercise
      )
    });
  };

  const removeExercise = (id: string) => {
    setCurrentWorkout({
      ...currentWorkout,
      exercises: currentWorkout.exercises.filter(exercise => exercise.id !== id)
    });
  };

  const saveCurrentWorkout = async () => {
    if (currentWorkout.exercises.length === 0) return;
    
    setLoading(true);
    try {
      // Create a new workout with current timestamp
      const workoutToSave = {
        ...currentWorkout,
        id: Date.now().toString(),
        date: new Date().toISOString()
      };

      await saveWorkout(workoutToSave);
      
      // Update local workouts state to reflect the new workout
      setWorkouts(prevWorkouts => [workoutToSave, ...prevWorkouts]);
      
      // Reset for new workout
      setCurrentWorkout({
        id: Date.now().toString(),
        date: new Date().toISOString(),
        name: t('workout.my_workout'),
        exercises: []
      });

      // Show success message or feedback
      console.log('Workout saved successfully!');
    } catch (error) {
      console.error('Error saving workout:', error);
    } finally {
      setLoading(false);
    }
  };

  const refreshWorkouts = async () => {
    try {
      const loadedWorkouts = await getWorkouts();
      setWorkouts(loadedWorkouts);
    } catch (error) {
      console.error('Error refreshing workouts:', error);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">{t('workout.title')}</h2>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowTimer(true)}
            className="flex items-center gap-1 px-3 py-2 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors"
          >
            <Play className="h-4 w-4 text-orange-500" />
            <span className="text-sm">{t('workout.timer')}</span>
          </button>
          <button 
            onClick={() => {
              setShowCalendar(!showCalendar);
              if (!showCalendar) {
                refreshWorkouts(); // Refresh workouts when opening calendar
              }
            }}
            className="flex items-center gap-1 px-3 py-2 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors"
          >
            <Calendar className="h-4 w-4 text-orange-500" />
            <span className="text-sm">{t('workout.history')}</span>
          </button>
        </div>
      </div>
      
      {showCalendar ? (
        <WorkoutCalendar 
          onClose={() => setShowCalendar(false)} 
          workouts={workouts}
          onRefresh={refreshWorkouts}
        />
      ) : (
        <div className="workout-form">
          <div className="mb-4">
            <input
              type="text"
              value={currentWorkout.name}
              onChange={(e) => setCurrentWorkout({ ...currentWorkout, name: e.target.value })}
              className="w-full px-4 py-2 bg-gray-800 rounded-md text-white border border-gray-700 focus:border-orange-500 focus:outline-none"
              placeholder={t('workout.workout_name')}
            />
          </div>
          
          {currentWorkout.exercises.map((exercise, exerciseIndex) => (
            <div key={exercise.id} className="mb-6 p-4 bg-gray-900 rounded-lg border border-gray-800">
              <div className="flex justify-between items-center mb-4">
                <input
                  type="text"
                  value={exercise.name}
                  onChange={(e) => updateExerciseName(exercise.id, e.target.value)}
                  className="bg-transparent border-b border-gray-700 px-2 py-1 focus:border-orange-500 focus:outline-none w-full"
                  placeholder={t('workout.exercise_name')}
                />
                <button
                  onClick={() => removeExercise(exercise.id)}
                  className="text-gray-500 hover:text-red-500"
                >
                  <XCircle className="h-5 w-5" />
                </button>
              </div>
              
              <div className="mb-2 grid grid-cols-12 gap-2 text-sm font-medium text-gray-400">
                <div className="col-span-2">{t('workout.set')}</div>
                <div className="col-span-5">{t('workout.reps')}</div>
                <div className="col-span-5">{t('workout.weight_kg')}</div>
              </div>
              
              {exercise.sets.map((set, setIndex) => (
                <div key={setIndex} className="grid grid-cols-12 gap-2 mb-2 items-center">
                  <div className="col-span-2 text-gray-500 text-center">{setIndex + 1}</div>
                  <div className="col-span-5">
                    <input
                      type="number"
                      value={set.reps || ''}
                      onChange={(e) => updateSet(exercise.id, setIndex, parseInt(e.target.value) || 0, set.weight)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-1 focus:border-orange-500 focus:outline-none"
                      placeholder={t('workout.reps')}
                    />
                  </div>
                  <div className="col-span-5">
                    <input
                      type="number"
                      value={set.weight || ''}
                      onChange={(e) => updateSet(exercise.id, setIndex, set.reps, parseFloat(e.target.value) || 0)}
                      className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-1 focus:border-orange-500 focus:outline-none"
                      placeholder={t('workout.weight')}
                    />
                  </div>
                </div>
              ))}
              
              <button
                onClick={() => addSet(exercise.id)}
                className="mt-2 text-sm px-3 py-1 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors text-white"
              >
                + {t('workout.add_set')}
              </button>
            </div>
          ))}
          
          <div className="flex gap-4 mt-6">
            <button
              onClick={addExercise}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors text-white"
            >
              <Plus className="h-4 w-4" />
              {t('workout.add_exercise')}
            </button>
            
            <button
              onClick={saveCurrentWorkout}
              disabled={currentWorkout.exercises.length === 0 || loading}
              className={`px-4 py-2 rounded-md text-white flex items-center gap-2 ${
                currentWorkout.exercises.length === 0 || loading
                  ? 'bg-gray-700 cursor-not-allowed'
                  : 'bg-orange-600 hover:bg-orange-700 transition-colors'
              }`}
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  {t('workout.saving')}
                </>
              ) : (
                t('workout.save_workout')
              )}
            </button>
          </div>
        </div>
      )}
      
      {showTimer && <TimerModal onClose={() => setShowTimer(false)} />}
    </div>
  );
};

export default WorkoutTracker;