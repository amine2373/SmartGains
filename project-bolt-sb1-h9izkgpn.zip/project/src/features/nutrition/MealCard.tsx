import React, { useState } from 'react';
import { Trash2, Camera, ChevronDown, ChevronUp, X, Edit3 } from 'lucide-react';
import { Meal, Food } from '../../types';

interface MealCardProps {
  meal: Meal;
  onUpdate: (meal: Meal) => void;
  onRemove: () => void;
  onAnalyze: () => void;
}

const MealCard: React.FC<MealCardProps> = ({ meal, onUpdate, onRemove, onAnalyze }) => {
  const [expanded, setExpanded] = useState(false);
  const [editingFood, setEditingFood] = useState<Food | null>(null);
  const [editValues, setEditValues] = useState({
    name: '',
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0
  });
  
  const toggleExpanded = () => {
    setExpanded(!expanded);
  };
  
  const handleEditFood = (food: Food) => {
    setEditingFood(food);
    setEditValues({
      name: food.name,
      calories: food.calories,
      protein: food.protein,
      carbs: food.carbs,
      fat: food.fat
    });
  };
  
  const handleSaveEdit = () => {
    if (!editingFood) return;
    
    const oldFood = meal.foods.find(f => f.id === editingFood.id);
    if (!oldFood) return;
    
    // Calculate differences for the totals
    const caloriesDiff = editValues.calories - oldFood.calories;
    const proteinDiff = editValues.protein - oldFood.protein;
    const carbsDiff = editValues.carbs - oldFood.carbs;
    const fatDiff = editValues.fat - oldFood.fat;
    
    const updatedMeal = {
      ...meal,
      foods: meal.foods.map(f => 
        f.id === editingFood.id 
          ? { ...f, ...editValues }
          : f
      ),
      totalCalories: meal.totalCalories + caloriesDiff,
      totalProtein: meal.totalProtein + proteinDiff,
      totalCarbs: meal.totalCarbs + carbsDiff,
      totalFat: meal.totalFat + fatDiff
    };
    
    onUpdate(updatedMeal);
    setEditingFood(null);
  };
  
  const handleRemoveFood = (foodId: string) => {
    const foodToRemove = meal.foods.find(f => f.id === foodId);
    if (!foodToRemove) return;
    
    const updatedMeal = {
      ...meal,
      foods: meal.foods.filter(f => f.id !== foodId),
      totalCalories: meal.totalCalories - foodToRemove.calories,
      totalProtein: meal.totalProtein - foodToRemove.protein,
      totalCarbs: meal.totalCarbs - foodToRemove.carbs,
      totalFat: meal.totalFat - foodToRemove.fat
    };
    
    onUpdate(updatedMeal);
  };
  
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 overflow-hidden">
      <div 
        className="p-4 flex justify-between items-center cursor-pointer"
        onClick={toggleExpanded}
      >
        <div>
          <h3 className="text-lg font-medium text-white">{meal.type}</h3>
          <p className="text-sm text-gray-400">{meal.totalCalories} calories</p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex gap-1">
            <div className="h-2 w-2 rounded-full bg-blue-500"></div>
            <div className="h-2 w-2 rounded-full bg-green-500"></div>
            <div className="h-2 w-2 rounded-full bg-yellow-500"></div>
          </div>
          
          {expanded ? (
            <ChevronUp className="h-5 w-5 text-gray-400" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-400" />
          )}
        </div>
      </div>
      
      {expanded && (
        <div className="p-4 border-t border-gray-800">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-sm font-medium text-gray-400">Macros</h4>
            <div className="flex gap-2">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onAnalyze();
                }}
                className="flex items-center gap-1 px-2 py-1 bg-gray-800 rounded hover:bg-gray-700 transition-colors"
              >
                <Camera className="h-4 w-4 text-orange-500" />
                <span className="text-xs">Add Food</span>
              </button>
              
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove();
                }}
                className="flex items-center gap-1 px-2 py-1 bg-gray-800 rounded hover:bg-gray-700 transition-colors"
              >
                <Trash2 className="h-4 w-4 text-red-500" />
                <span className="text-xs">Remove</span>
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-4 gap-2 mb-4">
            <div className="text-center p-2 bg-gray-800 rounded">
              <p className="text-xs text-gray-400">Calories</p>
              <p className="text-lg font-medium text-white">{meal.totalCalories}</p>
            </div>
            <div className="text-center p-2 bg-gray-800 rounded">
              <p className="text-xs text-gray-400">Protein</p>
              <p className="text-lg font-medium text-white">{meal.totalProtein}g</p>
            </div>
            <div className="text-center p-2 bg-gray-800 rounded">
              <p className="text-xs text-gray-400">Carbs</p>
              <p className="text-lg font-medium text-white">{meal.totalCarbs}g</p>
            </div>
            <div className="text-center p-2 bg-gray-800 rounded">
              <p className="text-xs text-gray-400">Fat</p>
              <p className="text-lg font-medium text-white">{meal.totalFat}g</p>
            </div>
          </div>
          
          {meal.foods.length > 0 ? (
            <div className="space-y-3">
              {meal.foods.map(food => (
                <div key={food.id} className="p-3 bg-gray-800 rounded flex justify-between items-center">
                  <div className="flex gap-3 items-center">
                    {food.photoUrl && (
                      <img 
                        src={food.photoUrl} 
                        alt={food.name} 
                        className="h-12 w-12 object-cover rounded" 
                      />
                    )}
                    <div>
                      <h5 className="text-sm font-medium text-white">{food.name}</h5>
                      <p className="text-xs text-gray-400">
                        {food.calories} cal | P: {food.protein}g | C: {food.carbs}g | F: {food.fat}g
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditFood(food);
                      }}
                      className="p-1 text-gray-400 hover:text-white"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveFood(food.id);
                      }}
                      className="p-1 text-gray-400 hover:text-red-500"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-4">No foods added yet.</p>
          )}
        </div>
      )}
      
      {editingFood && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-md w-full border border-gray-800 shadow-lg">
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-white">Edit Food</h3>
              <button onClick={() => setEditingFood(null)} className="text-gray-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Food Name</label>
                <input
                  type="text"
                  value={editValues.name}
                  onChange={(e) => setEditValues({ ...editValues, name: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Calories</label>
                <input
                  type="number"
                  value={editValues.calories}
                  onChange={(e) => setEditValues({ ...editValues, calories: parseInt(e.target.value) || 0 })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                />
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Protein (g)</label>
                  <input
                    type="number"
                    value={editValues.protein}
                    onChange={(e) => setEditValues({ ...editValues, protein: parseInt(e.target.value) || 0 })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Carbs (g)</label>
                  <input
                    type="number"
                    value={editValues.carbs}
                    onChange={(e) => setEditValues({ ...editValues, carbs: parseInt(e.target.value) || 0 })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Fat (g)</label>
                  <input
                    type="number"
                    value={editValues.fat}
                    onChange={(e) => setEditValues({ ...editValues, fat: parseInt(e.target.value) || 0 })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
              </div>
              
              <button
                onClick={handleSaveEdit}
                className="w-full mt-4 px-4 py-2 bg-orange-500 rounded-md hover:bg-orange-600 transition-colors text-white"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MealCard;