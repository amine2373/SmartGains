import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, X, RefreshCw, Calendar } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { getNutritionDays } from '../../utils/storage';
import { NutritionDay } from '../../types';

interface NutritionCalendarProps {
  onClose: () => void;
  onDateSelect: (date: Date) => void;
  nutritionDays?: NutritionDay[];
  onRefresh?: () => void;
}

const NutritionCalendar: React.FC<NutritionCalendarProps> = ({ 
  onClose, 
  onDateSelect, 
  nutritionDays: propNutritionDays, 
  onRefresh 
}) => {
  const { t, language } = useLanguage();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [nutritionDays, setNutritionDays] = useState<NutritionDay[]>(propNutritionDays || []);
  const [nutritionDaysMap, setNutritionDaysMap] = useState<Map<string, NutritionDay>>(new Map());
  const [loading, setLoading] = useState(!propNutritionDays);
  
  useEffect(() => {
    if (propNutritionDays) {
      setNutritionDays(propNutritionDays);
      updateNutritionDaysMap(propNutritionDays);
      setLoading(false);
    } else {
      loadNutritionDays();
    }
  }, [propNutritionDays]);

  const loadNutritionDays = async () => {
    setLoading(true);
    try {
      const allNutritionDays = await getNutritionDays();
      setNutritionDays(allNutritionDays);
      updateNutritionDaysMap(allNutritionDays);
    } catch (error) {
      console.error('Error loading nutrition days:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateNutritionDaysMap = (nutritionList: NutritionDay[]) => {
    const map = new Map<string, NutritionDay>();
    nutritionList.forEach(day => {
      const date = new Date(day.date);
      const key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
      map.set(key, day);
    });
    setNutritionDaysMap(map);
  };

  const handleRefresh = async () => {
    if (onRefresh) {
      onRefresh();
    } else {
      await loadNutritionDays();
    }
  };
  
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };
  
  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };
  
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    setSelectedDate(null);
  };
  
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    setSelectedDate(null);
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    onDateSelect(date);
  };

  const getDayNames = () => {
    return [
      t('days.sun'),
      t('days.mon'),
      t('days.tue'),
      t('days.wed'),
      t('days.thu'),
      t('days.fri'),
      t('days.sat')
    ];
  };
  
  const renderCalendar = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-12"></div>);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const dateString = `${year}-${month}-${day}`;
      const nutritionDay = nutritionDaysMap.get(dateString);
      const hasNutrition = !!nutritionDay;
      
      const isSelected = selectedDate 
        ? day === selectedDate.getDate() && 
          month === selectedDate.getMonth() && 
          year === selectedDate.getFullYear()
        : false;

      const isToday = new Date().toDateString() === date.toDateString();
        
      days.push(
        <div 
          key={`day-${day}`}
          onClick={() => handleDateClick(date)}
          className={`h-12 flex flex-col items-center justify-center rounded-lg cursor-pointer transition-colors relative ${
            isSelected 
              ? 'bg-orange-500 text-white'
              : isToday
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                : hasNutrition 
                  ? 'bg-gray-800 text-white hover:bg-gray-700' 
                  : 'text-gray-400 hover:bg-gray-800'
          }`}
        >
          <span className="text-sm font-medium">{day}</span>
          {hasNutrition && (
            <div className="flex gap-0.5 mt-0.5">
              <div className="w-1 h-1 rounded-full bg-green-500"></div>
              <div className="w-1 h-1 rounded-full bg-blue-500"></div>
              <div className="w-1 h-1 rounded-full bg-yellow-500"></div>
            </div>
          )}
        </div>
      );
    }
    
    return days;
  };
  
  const getSelectedDateNutrition = () => {
    if (!selectedDate) return null;
    
    const dateString = `${selectedDate.getFullYear()}-${selectedDate.getMonth()}-${selectedDate.getDate()}`;
    return nutritionDaysMap.get(dateString);
  };
  
  const selectedNutrition = getSelectedDateNutrition();

  const calculateDayTotals = (nutritionDay: NutritionDay) => {
    let calories = 0, protein = 0, carbs = 0, fat = 0;
    
    nutritionDay.meals.forEach(meal => {
      calories += meal.totalCalories;
      protein += meal.totalProtein;
      carbs += meal.totalCarbs;
      fat += meal.totalFat;
    });
    
    return { calories, protein, carbs, fat };
  };
  
  if (loading) {
    return (
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-white">{t('nutrition.calendar_title')}</h3>
        <div className="flex gap-2">
          <button 
            onClick={handleRefresh} 
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors"
            title={t('nutrition.refresh_data')}
          >
            <RefreshCw className="h-4 w-4" />
          </button>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      <div className="calendar mb-6">
        <div className="flex justify-between items-center mb-4">
          <button onClick={prevMonth} className="p-1 hover:bg-gray-800 rounded">
            <ArrowLeft className="h-5 w-5 text-gray-400" />
          </button>
          
          <h4 className="text-lg font-medium text-white">
            {currentDate.toLocaleString(language === 'en' ? 'en-US' : language === 'es' ? 'es-ES' : language === 'fr' ? 'fr-FR' : language === 'de' ? 'de-DE' : 'ar-SA', { month: 'long', year: 'numeric' })}
          </h4>
          
          <button onClick={nextMonth} className="p-1 hover:bg-gray-800 rounded">
            <ArrowRight className="h-5 w-5 text-gray-400" />
          </button>
        </div>
        
        <div className="grid grid-cols-7 gap-1 mb-1">
          {getDayNames().map(day => (
            <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {renderCalendar()}
        </div>
      </div>

      {/* Nutrition count indicator */}
      <div className="mb-4 text-center">
        <p className="text-sm text-gray-400">
          {t('nutrition.days_recorded')}: <span className="text-orange-500 font-semibold">{nutritionDays.length}</span>
        </p>
      </div>
      
      {selectedDate && (
        <div className="selected-date">
          <h4 className="text-lg font-medium text-white mb-3">
            {selectedDate.toLocaleDateString(language === 'en' ? 'en-US' : language === 'es' ? 'es-ES' : language === 'fr' ? 'fr-FR' : language === 'de' ? 'de-DE' : 'ar-SA', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </h4>
          
          {selectedNutrition ? (
            <div className="space-y-4">
              {/* Daily totals */}
              <div className="grid grid-cols-4 gap-3">
                {(() => {
                  const totals = calculateDayTotals(selectedNutrition);
                  return (
                    <>
                      <div className="bg-gray-800 rounded-lg p-3 text-center">
                        <p className="text-xs text-gray-400">{t('common.calories')}</p>
                        <p className="text-lg font-bold text-white">{totals.calories}</p>
                      </div>
                      <div className="bg-gray-800 rounded-lg p-3 text-center">
                        <p className="text-xs text-gray-400">{t('nutrition.protein')}</p>
                        <p className="text-lg font-bold text-white">{totals.protein}g</p>
                      </div>
                      <div className="bg-gray-800 rounded-lg p-3 text-center">
                        <p className="text-xs text-gray-400">{t('nutrition.carbs')}</p>
                        <p className="text-lg font-bold text-white">{totals.carbs}g</p>
                      </div>
                      <div className="bg-gray-800 rounded-lg p-3 text-center">
                        <p className="text-xs text-gray-400">{t('nutrition.fat')}</p>
                        <p className="text-lg font-bold text-white">{totals.fat}g</p>
                      </div>
                    </>
                  );
                })()}
              </div>

              {/* Meals summary */}
              <div className="space-y-3">
                <h5 className="text-sm font-medium text-gray-300">{t('nutrition.daily_meals')}</h5>
                {selectedNutrition.meals.map(meal => (
                  <div key={meal.id} className="bg-gray-800 rounded-lg p-3 border border-gray-700">
                    <div className="flex justify-between items-center mb-2">
                      <h6 className="text-white font-medium">{meal.type}</h6>
                      <span className="text-sm text-orange-400">{meal.totalCalories} cal</span>
                    </div>
                    
                    <div className="text-xs text-gray-400 grid grid-cols-3 gap-2">
                      <span>P: {meal.totalProtein}g</span>
                      <span>C: {meal.totalCarbs}g</span>
                      <span>F: {meal.totalFat}g</span>
                    </div>
                    
                    {meal.foods.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-gray-700">
                        <p className="text-xs text-gray-500 mb-1">{t('nutrition.foods')} ({meal.foods.length}):</p>
                        <div className="space-y-1">
                          {meal.foods.slice(0, 3).map(food => (
                            <p key={food.id} className="text-xs text-gray-400 truncate">
                              • {food.name} ({food.calories} cal)
                            </p>
                          ))}
                          {meal.foods.length > 3 && (
                            <p className="text-xs text-gray-500">
                              ... {t('nutrition.and_others')} {meal.foods.length - 3} {t('nutrition.others')}
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-6">
              <Calendar className="h-12 w-12 mx-auto mb-3 text-gray-600" />
              <p className="text-gray-400">{t('nutrition.no_data_day')}</p>
              <button
                onClick={() => {
                  onDateSelect(selectedDate);
                  onClose();
                }}
                className="mt-3 px-4 py-2 bg-orange-500 hover:bg-orange-600 transition-colors rounded-md text-white text-sm"
              >
                {t('nutrition.add_meals')}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NutritionCalendar;