import React, { useState, useEffect } from 'react';
import { PlusCircle, Camera, Calendar, X } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import MealCard from './MealCard';
import FoodAnalysisModal from './FoodAnalysisModal';
import NutritionCalendar from './NutritionCalendar';
import { Meal, NutritionDay } from '../../types';
import { getNutritionDays, saveNutritionDay } from '../../utils/storage';

const MEAL_TYPES = ['Breakfast', 'Lunch', 'Dinner', 'Snack'];

const NutritionTracker: React.FC = () => {
  const { t } = useLanguage();
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedMealType, setSelectedMealType] = useState('');
  const [loading, setLoading] = useState(true);
  const [allNutritionDays, setAllNutritionDays] = useState<NutritionDay[]>([]);
  const [nutritionData, setNutritionData] = useState<NutritionDay>({
    id: '',
    date: currentDate.toISOString(),
    meals: []
  });
  
  useEffect(() => {
    const loadNutritionData = async () => {
      try {
        // Load all nutrition data
        const allNutritionDays = await getNutritionDays();
        setAllNutritionDays(allNutritionDays);
        
        // Find data for current date
        const today = allNutritionDays.find(day => {
          const dayDate = new Date(day.date);
          return dayDate.getDate() === currentDate.getDate() && 
                 dayDate.getMonth() === currentDate.getMonth() && 
                 dayDate.getFullYear() === currentDate.getFullYear();
        });
        
        if (today) {
          setNutritionData(today);
        } else {
          setNutritionData({
            id: '',
            date: currentDate.toISOString(),
            meals: []
          });
        }
      } catch (error) {
        console.error('Error loading nutrition data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadNutritionData();
  }, [currentDate]);

  const refreshNutritionData = async () => {
    try {
      const allNutritionDays = await getNutritionDays();
      setAllNutritionDays(allNutritionDays);
      
      // Update current day data
      const today = allNutritionDays.find(day => {
        const dayDate = new Date(day.date);
        return dayDate.getDate() === currentDate.getDate() && 
               dayDate.getMonth() === currentDate.getMonth() && 
               dayDate.getFullYear() === currentDate.getFullYear();
      });
      
      if (today) {
        setNutritionData(today);
      }
    } catch (error) {
      console.error('Error refreshing nutrition data:', error);
    }
  };

  const handleDateSelect = (date: Date) => {
    setCurrentDate(date);
    setShowCalendar(false);
  };

  const changeDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setDate(newDate.getDate() - 1);
    } else {
      newDate.setDate(newDate.getDate() + 1);
    }
    setCurrentDate(newDate);
  };

  const getMealTypeName = (type: string) => {
    switch (type) {
      case 'Breakfast': return t('nutrition.breakfast');
      case 'Lunch': return t('nutrition.lunch');
      case 'Dinner': return t('nutrition.dinner');
      case 'Snack': return t('nutrition.snack');
      default: return type;
    }
  };
  
  const addMeal = async (type: string) => {
    const existingMeal = nutritionData.meals.find(meal => meal.type === type);
    
    if (!existingMeal) {
      const newMeal: Meal = {
        id: Date.now().toString(),
        type,
        foods: [],
        totalCalories: 0,
        totalProtein: 0,
        totalCarbs: 0,
        totalFat: 0
      };
      
      const updatedData = {
        ...nutritionData,
        meals: [...nutritionData.meals, newMeal]
      };
      
      try {
        const savedId = await saveNutritionDay(updatedData);
        setNutritionData({
          ...updatedData,
          id: savedId
        });
        
        // Refresh all nutrition days
        await refreshNutritionData();
      } catch (error) {
        console.error('Error saving nutrition data:', error);
      }
    }
  };
  
  const updateMeal = async (mealId: string, updatedMeal: Meal) => {
    const updatedData = {
      ...nutritionData,
      meals: nutritionData.meals.map(meal => 
        meal.id === mealId ? updatedMeal : meal
      )
    };
    
    try {
      const savedId = await saveNutritionDay(updatedData);
      setNutritionData({
        ...updatedData,
        id: savedId
      });
      
      // Refresh all nutrition days
      await refreshNutritionData();
    } catch (error) {
      console.error('Error updating meal:', error);
    }
  };
  
  const removeMeal = async (mealId: string) => {
    const updatedData = {
      ...nutritionData,
      meals: nutritionData.meals.filter(meal => meal.id !== mealId)
    };
    
    try {
      const savedId = await saveNutritionDay(updatedData);
      setNutritionData({
        ...updatedData,
        id: savedId
      });
      
      // Refresh all nutrition days
      await refreshNutritionData();
    } catch (error) {
      console.error('Error removing meal:', error);
    }
  };
  
  const handleOpenAnalysis = (mealType: string) => {
    setSelectedMealType(mealType);
    setShowAnalysis(true);
  };
  
  const handleCloseAnalysis = () => {
    setShowAnalysis(false);
    setSelectedMealType('');
  };
  
  const calculateDailyTotals = () => {
    let calories = 0, protein = 0, carbs = 0, fat = 0;
    
    nutritionData.meals.forEach(meal => {
      calories += meal.totalCalories;
      protein += meal.totalProtein;
      carbs += meal.totalCarbs;
      fat += meal.totalFat;
    });
    
    return { calories, protein, carbs, fat };
  };
  
  const totals = calculateDailyTotals();

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
      </div>
    );
  }
  
  return (
    <div>
      {showCalendar ? (
        <NutritionCalendar 
          onClose={() => setShowCalendar(false)}
          onDateSelect={handleDateSelect}
          nutritionDays={allNutritionDays}
          onRefresh={refreshNutritionData}
        />
      ) : (
        <>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">{t('nutrition.title')}</h2>
            <div className="flex items-center gap-3">
              {/* Date navigation */}
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => changeDate('prev')}
                  className="p-1 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors"
                >
                  ←
                </button>
                <button 
                  onClick={() => setShowCalendar(true)}
                  className="flex items-center gap-1 px-3 py-2 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors"
                >
                  <Calendar className="h-4 w-4 text-orange-500" />
                  <span className="text-sm">
                    {currentDate.toLocaleDateString('en-US', { 
                      day: 'numeric', 
                      month: 'short', 
                      year: currentDate.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined 
                    })}
                  </span>
                </button>
                <button 
                  onClick={() => changeDate('next')}
                  className="p-1 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors"
                >
                  →
                </button>
              </div>
            </div>
          </div>
          
          <div className="stats-cards grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="stat-card bg-gray-900 rounded-lg p-4 border border-gray-800">
              <h3 className="text-sm font-medium text-gray-400 mb-1">{t('common.calories')}</h3>
              <p className="text-2xl font-bold text-white">{totals.calories}</p>
              <div className="w-full h-1 bg-gray-800 mt-2">
                <div 
                  className="h-1 bg-orange-500" 
                  style={{ width: `${Math.min(100, (totals.calories / 2500) * 100)}%` }}
                ></div>
              </div>
            </div>
            
            <div className="stat-card bg-gray-900 rounded-lg p-4 border border-gray-800">
              <h3 className="text-sm font-medium text-gray-400 mb-1">{t('nutrition.protein')}</h3>
              <p className="text-2xl font-bold text-white">{totals.protein}g</p>
              <div className="w-full h-1 bg-gray-800 mt-2">
                <div 
                  className="h-1 bg-blue-500" 
                  style={{ width: `${Math.min(100, (totals.protein / 150) * 100)}%` }}
                ></div>
              </div>
            </div>
            
            <div className="stat-card bg-gray-900 rounded-lg p-4 border border-gray-800">
              <h3 className="text-sm font-medium text-gray-400 mb-1">{t('nutrition.carbs')}</h3>
              <p className="text-2xl font-bold text-white">{totals.carbs}g</p>
              <div className="w-full h-1 bg-gray-800 mt-2">
                <div 
                  className="h-1 bg-green-500" 
                  style={{ width: `${Math.min(100, (totals.carbs / 300) * 100)}%` }}
                ></div>
              </div>
            </div>
            
            <div className="stat-card bg-gray-900 rounded-lg p-4 border border-gray-800">
              <h3 className="text-sm font-medium text-gray-400 mb-1">{t('nutrition.fat')}</h3>
              <p className="text-2xl font-bold text-white">{totals.fat}g</p>
              <div className="w-full h-1 bg-gray-800 mt-2">
                <div 
                  className="h-1 bg-yellow-500" 
                  style={{ width: `${Math.min(100, (totals.fat / 80) * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          <div className="meals-section space-y-6">
            {nutritionData.meals.map(meal => (
              <MealCard 
                key={meal.id} 
                meal={meal} 
                onUpdate={updatedMeal => updateMeal(meal.id, updatedMeal)}
                onRemove={() => removeMeal(meal.id)}
                onAnalyze={() => handleOpenAnalysis(meal.type)}
              />
            ))}
            
            <div className="add-meal grid grid-cols-2 md:grid-cols-4 gap-4">
              {MEAL_TYPES.map(type => {
                const exists = nutritionData.meals.some(meal => meal.type === type);
                
                if (exists) return null;
                
                return (
                  <button
                    key={type}
                    onClick={() => addMeal(type)}
                    className="flex flex-col items-center justify-center gap-2 p-4 bg-gray-900 rounded-lg border border-gray-800 hover:bg-gray-800 transition-colors"
                  >
                    <PlusCircle className="h-6 w-6 text-orange-500" />
                    <span className="text-sm font-medium text-white">{t('nutrition.add')} {getMealTypeName(type)}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
      
      {showAnalysis && (
        <FoodAnalysisModal 
          mealType={selectedMealType} 
          onClose={handleCloseAnalysis}
          onSave={async (foodData) => {
            const mealToUpdate = nutritionData.meals.find(meal => meal.type === selectedMealType);
            
            if (mealToUpdate) {
              const updatedMeal = {
                ...mealToUpdate,
                foods: [...mealToUpdate.foods, {
                  id: Date.now().toString(),
                  name: foodData.name || 'Unknown Food',
                  calories: foodData.calories,
                  protein: foodData.protein,
                  carbs: foodData.carbs,
                  fat: foodData.fat,
                  photoUrl: foodData.photoUrl || null
                }],
                totalCalories: mealToUpdate.totalCalories + foodData.calories,
                totalProtein: mealToUpdate.totalProtein + foodData.protein,
                totalCarbs: mealToUpdate.totalCarbs + foodData.carbs,
                totalFat: mealToUpdate.totalFat + foodData.fat
              };
              
              await updateMeal(mealToUpdate.id, updatedMeal);
              handleCloseAnalysis();
            }
          }}
        />
      )}
    </div>
  );
};

export default NutritionTracker;