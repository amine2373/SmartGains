import React, { useState } from 'react';
import { X, Loader2 } from 'lucide-react';

interface FoodAnalysisModalProps {
  mealType: string;
  onClose: () => void;
  onSave: (foodData: {
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }) => void;
}

const FoodAnalysisModal: React.FC<FoodAnalysisModalProps> = ({ mealType, onClose, onSave }) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [foodInput, setFoodInput] = useState({
    name: '',
    weight: ''
  });
  const [foodData, setFoodData] = useState({
    name: '',
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0
  });
  
  const analyzeFood = async () => {
    if (!foodInput.name || !foodInput.weight) return;
    
    setAnalyzing(true);
    
    try {
      // Format the prompt for Gemini
      const prompt = `Given a food item "${foodInput.name}" weighing ${foodInput.weight}g, estimate its nutritional values. 
      Return only the following values in a JSON format:
      - calories (total calories)
      - protein (grams)
      - carbs (grams)
      - fat (grams)`;
      
      // In a real implementation, this would be an API call to Gemini
      // For now, simulate a response based on common foods
      setTimeout(() => {
        let estimatedValues;
        
        // Simple simulation based on common foods
        if (foodInput.name.toLowerCase().includes('chicken')) {
          estimatedValues = {
            calories: Math.round((165 / 100) * parseInt(foodInput.weight)),
            protein: Math.round((31 / 100) * parseInt(foodInput.weight)),
            carbs: 0,
            fat: Math.round((3.6 / 100) * parseInt(foodInput.weight))
          };
        } else if (foodInput.name.toLowerCase().includes('rice')) {
          estimatedValues = {
            calories: Math.round((130 / 100) * parseInt(foodInput.weight)),
            protein: Math.round((2.7 / 100) * parseInt(foodInput.weight)),
            carbs: Math.round((28 / 100) * parseInt(foodInput.weight)),
            fat: Math.round((0.3 / 100) * parseInt(foodInput.weight))
          };
        } else {
          // Default values for unknown foods
          estimatedValues = {
            calories: Math.round((150 / 100) * parseInt(foodInput.weight)),
            protein: Math.round((5 / 100) * parseInt(foodInput.weight)),
            carbs: Math.round((15 / 100) * parseInt(foodInput.weight)),
            fat: Math.round((8 / 100) * parseInt(foodInput.weight))
          };
        }
        
        setFoodData({
          name: foodInput.name,
          ...estimatedValues
        });
        setAnalyzing(false);
      }, 1500);
      
    } catch (error) {
      console.error('Error analyzing food:', error);
      setAnalyzing(false);
    }
  };
  
  const handleSave = () => {
    onSave(foodData);
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-xl max-w-md w-full border border-gray-800 shadow-lg">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-white">Add Food to {mealType}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="mb-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Food Name</label>
                <input
                  type="text"
                  value={foodInput.name}
                  onChange={(e) => setFoodInput({ ...foodInput, name: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  placeholder="e.g., Grilled Chicken Breast"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Weight (grams)</label>
                <input
                  type="number"
                  value={foodInput.weight}
                  onChange={(e) => setFoodInput({ ...foodInput, weight: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  placeholder="e.g., 100"
                />
              </div>
              
              <button
                onClick={analyzeFood}
                disabled={!foodInput.name || !foodInput.weight || analyzing}
                className="w-full flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 transition-colors px-4 py-2 rounded-md text-white disabled:bg-gray-700 disabled:cursor-not-allowed"
              >
                {analyzing ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  'Analyze with AI'
                )}
              </button>
            </div>
          </div>
          
          {foodData.calories > 0 && (
            <div className="space-y-4 border-t border-gray-800 pt-6">
              <h4 className="text-sm font-medium text-gray-300">Estimated Nutritional Values</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-800 p-3 rounded-lg">
                  <p className="text-sm text-gray-400">Calories</p>
                  <p className="text-xl font-bold text-white">{foodData.calories}</p>
                </div>
                
                <div className="bg-gray-800 p-3 rounded-lg">
                  <p className="text-sm text-gray-400">Protein</p>
                  <p className="text-xl font-bold text-white">{foodData.protein}g</p>
                </div>
                
                <div className="bg-gray-800 p-3 rounded-lg">
                  <p className="text-sm text-gray-400">Carbs</p>
                  <p className="text-xl font-bold text-white">{foodData.carbs}g</p>
                </div>
                
                <div className="bg-gray-800 p-3 rounded-lg">
                  <p className="text-sm text-gray-400">Fat</p>
                  <p className="text-xl font-bold text-white">{foodData.fat}g</p>
                </div>
              </div>
              
              <button
                onClick={handleSave}
                className="w-full mt-4 px-4 py-2 bg-orange-500 rounded-md hover:bg-orange-600 transition-colors text-white"
              >
                Save Food
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FoodAnalysisModal;