import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, AlertCircle, Brain, Loader2, Calendar, Dumbbell, Utensils } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { getWorkouts, getNutritionDays, getBodyMetrics } from '../../utils/storage';
import { Workout, NutritionDay, BodyMetric } from '../../types';

const DataAnalysis: React.FC = () => {
  const { t, language } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [question, setQuestion] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [nutritionDays, setNutritionDays] = useState<NutritionDay[]>([]);
  const [bodyMetrics, setBodyMetrics] = useState<BodyMetric[]>([]);
  const [dataLoaded, setDataLoaded] = useState(false);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [workoutData, nutritionData, metricsData] = await Promise.all([
        getWorkouts(),
        getNutritionDays(),
        getBodyMetrics()
      ]);
      
      setWorkouts(workoutData);
      setNutritionDays(nutritionData);
      setBodyMetrics(metricsData);
      setDataLoaded(true);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDataForAI = () => {
    // Format workout data with more details
    const workoutSummary = workouts.map(workout => {
      const totalSets = workout.exercises.reduce((sum, ex) => sum + ex.sets.length, 0);
      const totalReps = workout.exercises.reduce((sum, ex) => sum + ex.sets.reduce((reps, set) => reps + set.reps, 0), 0);
      const totalVolume = workout.exercises.reduce((sum, ex) => sum + ex.sets.reduce((vol, set) => vol + (set.weight * set.reps), 0), 0);
      
      return {
        date: new Date(workout.date).toLocaleDateString(language === 'en' ? 'en-US' : language === 'es' ? 'es-ES' : language === 'fr' ? 'fr-FR' : language === 'de' ? 'de-DE' : 'ar-SA'),
        name: workout.name,
        totalExercises: workout.exercises.length,
        totalSets,
        totalReps,
        totalVolume: Math.round(totalVolume),
        exercises: workout.exercises.map(ex => ({
          name: ex.name,
          sets: ex.sets.length,
          totalReps: ex.sets.reduce((sum, set) => sum + set.reps, 0),
          totalWeight: ex.sets.reduce((sum, set) => sum + (set.weight * set.reps), 0),
          maxWeight: Math.max(...ex.sets.map(set => set.weight)),
          avgReps: Math.round(ex.sets.reduce((sum, set) => sum + set.reps, 0) / ex.sets.length)
        }))
      };
    });

    // Format nutrition data with more analysis
    const nutritionSummary = nutritionDays.map(day => {
      const totalCalories = day.meals.reduce((sum, meal) => sum + meal.totalCalories, 0);
      const totalProtein = day.meals.reduce((sum, meal) => sum + meal.totalProtein, 0);
      const totalCarbs = day.meals.reduce((sum, meal) => sum + meal.totalCarbs, 0);
      const totalFat = day.meals.reduce((sum, meal) => sum + meal.totalFat, 0);
      
      // Calculate macros percentages
      const proteinCals = totalProtein * 4;
      const carbsCals = totalCarbs * 4;
      const fatCals = totalFat * 9;
      const totalMacroCals = proteinCals + carbsCals + fatCals;
      
      return {
        date: new Date(day.date).toLocaleDateString(language === 'en' ? 'en-US' : language === 'es' ? 'es-ES' : language === 'fr' ? 'fr-FR' : language === 'de' ? 'de-DE' : 'ar-SA'),
        calories: totalCalories,
        protein: totalProtein,
        carbs: totalCarbs,
        fat: totalFat,
        mealsCount: day.meals.length,
        proteinPercentage: totalMacroCals > 0 ? Math.round((proteinCals / totalMacroCals) * 100) : 0,
        carbsPercentage: totalMacroCals > 0 ? Math.round((carbsCals / totalMacroCals) * 100) : 0,
        fatPercentage: totalMacroCals > 0 ? Math.round((fatCals / totalMacroCals) * 100) : 0,
        caloriesPerKg: bodyMetrics.length > 0 ? Math.round(totalCalories / bodyMetrics[bodyMetrics.length - 1].weight) : null,
        proteinPerKg: bodyMetrics.length > 0 ? Math.round((totalProtein / bodyMetrics[bodyMetrics.length - 1].weight) * 10) / 10 : null
      };
    });

    // Format body metrics with trends
    const metricsSummary = bodyMetrics.map((metric, index) => {
      const prevMetric = index > 0 ? bodyMetrics[index - 1] : null;
      
      return {
        date: new Date(metric.date).toLocaleDateString(language === 'en' ? 'en-US' : language === 'es' ? 'es-ES' : language === 'fr' ? 'fr-FR' : language === 'de' ? 'de-DE' : 'ar-SA'),
        weight: metric.weight,
        bodyFat: metric.bodyFat,
        bmi: metric.bmi,
        testosterone: metric.testosterone,
        weightChange: prevMetric ? Math.round((metric.weight - prevMetric.weight) * 10) / 10 : 0,
        bodyFatChange: prevMetric ? Math.round((metric.bodyFat - prevMetric.bodyFat) * 10) / 10 : 0,
        bmiChange: prevMetric ? Math.round((metric.bmi - prevMetric.bmi) * 10) / 10 : 0,
        testosteroneChange: prevMetric ? Math.round(metric.testosterone - prevMetric.testosterone) : 0
      };
    });

    // Calculate overall statistics
    const stats = {
      totalWorkouts: workouts.length,
      totalNutritionDays: nutritionDays.length,
      totalMetrics: bodyMetrics.length,
      avgCaloriesPerDay: nutritionDays.length > 0 ? Math.round(nutritionDays.reduce((sum, day) => sum + day.meals.reduce((mealSum, meal) => mealSum + meal.totalCalories, 0), 0) / nutritionDays.length) : 0,
      avgProteinPerDay: nutritionDays.length > 0 ? Math.round(nutritionDays.reduce((sum, day) => sum + day.meals.reduce((mealSum, meal) => mealSum + meal.totalProtein, 0), 0) / nutritionDays.length) : 0,
      workoutFrequency: workouts.length > 0 ? Math.round((workouts.length / 30) * 10) / 10 : 0, // workouts per month approximation
      currentWeight: bodyMetrics.length > 0 ? bodyMetrics[bodyMetrics.length - 1].weight : null,
      weightTrend: bodyMetrics.length > 1 ? bodyMetrics[bodyMetrics.length - 1].weight - bodyMetrics[0].weight : 0
    };

    return {
      workouts: workoutSummary,
      nutrition: nutritionSummary,
      bodyMetrics: metricsSummary,
      overallStats: stats
    };
  };

  const analyzeData = async () => {
    if (!question.trim() || !dataLoaded) return;

    setAnalyzing(true);
    
    try {
      const userData = formatDataForAI();
      
      const getPromptForLanguage = () => {
        const baseData = `
COMPLETE USER DATA:

GENERAL STATISTICS:
${JSON.stringify(userData.overallStats, null, 2)}

WORKOUT HISTORY (${userData.workouts.length} sessions):
${JSON.stringify(userData.workouts, null, 2)}

NUTRITION HISTORY (${userData.nutrition.length} days):
${JSON.stringify(userData.nutrition, null, 2)}

BODY METRICS EVOLUTION (${userData.bodyMetrics.length} measurements):
${JSON.stringify(userData.bodyMetrics, null, 2)}

USER QUESTION: ${question}`;

        switch (language) {
          case 'es':
            return `Eres un experto en fitness y nutrición con más de 15 años de experiencia. Debes analizar los datos del usuario y proporcionar una respuesta MUY DETALLADA y COMPLETA.

${baseData}

INSTRUCCIONES PARA TU RESPUESTA:
1. Proporciona un análisis PROFUNDO y DETALLADO (mínimo 400-500 palabras)
2. Estructura tu respuesta con secciones claras y subtítulos
3. Analiza tendencias y patrones en los datos
4. Da recomendaciones ESPECÍFICAS y ACCIONABLES
5. Explica el "por qué" científico detrás de cada consejo
6. Incluye ejemplos concretos y números precisos
7. Menciona fortalezas Y áreas de mejora
8. Propón un plan de acción paso a paso
9. Agrega consejos de seguridad y progresión
10. Termina con aliento personalizado basado en los datos

Usa los datos reales para respaldar cada punto de tu análisis. Sé preciso, científico pero accesible.`;

          case 'ar':
            return `أنت خبير في اللياقة البدنية والتغذية مع أكثر من 15 عامًا من الخبرة. يجب أن تحلل بيانات المستخدم وتقدم استجابة مفصلة جداً وشاملة.

${baseData}

تعليمات لاستجابتك:
1. قدم تحليلاً عميقاً ومفصلاً (400-500 كلمة كحد أدنى)
2. هيكل استجابتك بأقسام واضحة وعناوين فرعية
3. حلل الاتجاهات والأنماط في البيانات
4. قدم توصيات محددة وقابلة للتطبيق
5. اشرح "لماذا" العلمي وراء كل نصيحة
6. اشمل أمثلة ملموسة وأرقام دقيقة
7. اذكر نقاط القوة ومجالات التحسين
8. اقترح خطة عمل خطوة بخطوة
9. أضف نصائح السلامة والتقدم
10. اختتم بتشجيع شخصي مبني على البيانات

استخدم البيانات الحقيقية لدعم كل نقطة في تحليلك. كن دقيقاً وعلمياً لكن مفهوماً.`;

          case 'fr':
            return `Tu es un expert en fitness et nutrition avec plus de 15 ans d'expérience. Tu dois analyser les données de l'utilisateur et fournir une réponse TRÈS DÉTAILLÉE et COMPLÈTE.

${baseData}

INSTRUCTIONS POUR TA RÉPONSE:
1. Fournis une analyse APPROFONDIE et DÉTAILLÉE (minimum 400-500 mots)
2. Structure ta réponse avec des sections claires et des sous-titres
3. Analyse les tendances et patterns dans les données
4. Donne des recommandations SPÉCIFIQUES et ACTIONABLES
5. Explique le "pourquoi" scientifique derrière chaque conseil
6. Inclus des exemples concrets et des chiffres précis
7. Mentionne les points forts ET les axes d'amélioration
8. Propose un plan d'action étape par étape
9. Ajoute des conseils de sécurité et de progression
10. Termine par des encouragements personnalisés basés sur les données

Utilise les données réelles pour étayer chaque point de ton analyse. Sois précis, scientifique mais accessible.`;

          case 'de':
            return `Du bist ein Experte für Fitness und Ernährung mit über 15 Jahren Erfahrung. Du musst die Benutzerdaten analysieren und eine SEHR DETAILLIERTE und UMFASSENDE Antwort geben.

${baseData}

ANWEISUNGEN FÜR DEINE ANTWORT:
1. Liefere eine TIEFGREIFENDE und DETAILLIERTE Analyse (mindestens 400-500 Wörter)
2. Strukturiere deine Antwort mit klaren Abschnitten und Untertiteln
3. Analysiere Trends und Muster in den Daten
4. Gib SPEZIFISCHE und UMSETZBARE Empfehlungen
5. Erkläre das wissenschaftliche "Warum" hinter jedem Rat
6. Füge konkrete Beispiele und präzise Zahlen hinzu
7. Erwähne Stärken UND Verbesserungsbereiche
8. Schlage einen schrittweisen Aktionsplan vor
9. Füge Sicherheits- und Fortschrittstipps hinzu
10. Beende mit personalisierter Ermutigung basierend auf den Daten

Verwende die echten Daten, um jeden Punkt deiner Analyse zu unterstützen. Sei präzise, wissenschaftlich aber zugänglich.`;

          default: // English
            return `You are a fitness and nutrition expert with over 15 years of experience. You must analyze the user's data and provide a VERY DETAILED and COMPREHENSIVE response.

${baseData}

INSTRUCTIONS FOR YOUR RESPONSE:
1. Provide an IN-DEPTH and DETAILED analysis (minimum 400-500 words)
2. Structure your response with clear sections and subheadings
3. Analyze trends and patterns in the data
4. Give SPECIFIC and ACTIONABLE recommendations
5. Explain the scientific "why" behind each piece of advice
6. Include concrete examples and precise numbers
7. Mention strengths AND areas for improvement
8. Propose a step-by-step action plan
9. Add safety and progression tips
10. End with personalized encouragement based on the data

Use the real data to support every point in your analysis. Be precise, scientific but accessible.`;
        }
      };

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=AIzaSyDOdQCOA7HqOvFXo4gbAN1RGoYDnbXWB60`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: getPromptForLanguage()
            }]
          }],
          generationConfig: {
            temperature: 0.3,
            topK: 40,
            topP: 0.9,
            maxOutputTokens: 2000,
          }
        })
      });

      const data = await response.json();
      let aiResponse = t('analysis.cannot_analyze');

      if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
        aiResponse = data.candidates[0].content.parts[0].text;
      } else if (data.error) {
        aiResponse = `Error: ${data.error.message || 'Unable to process your request'}`;
      }

      setAnalysis(aiResponse);
    } catch (error) {
      console.error('Error analyzing data:', error);
      setAnalysis(t('analysis.connection_error_analysis'));
    } finally {
      setAnalyzing(false);
    }
  };

  const getDataStats = () => {
    return {
      workouts: workouts.length,
      nutritionDays: nutritionDays.length,
      bodyMetrics: bodyMetrics.length,
      totalDays: Math.max(
        workouts.length > 0 ? Math.ceil((Date.now() - new Date(workouts[workouts.length - 1].date).getTime()) / (1000 * 60 * 60 * 24)) : 0,
        nutritionDays.length > 0 ? Math.ceil((Date.now() - new Date(nutritionDays[nutritionDays.length - 1].date).getTime()) / (1000 * 60 * 60 * 24)) : 0,
        bodyMetrics.length > 0 ? Math.ceil((Date.now() - new Date(bodyMetrics[bodyMetrics.length - 1].date).getTime()) / (1000 * 60 * 60 * 24)) : 0
      )
    };
  };

  const stats = getDataStats();

  const getSuggestedQuestions = () => {
    switch (language) {
      case 'es':
        return [
          "Análisis completo de mi progreso con recomendaciones detalladas para las próximas 4 semanas",
          "Evaluación profunda de mi nutrición: equilibrio, timing y posibles optimizaciones",
          "Plan de mejora de mis entrenamientos basado en mi rendimiento actual",
          "Análisis de mis métricas corporales y estrategias para optimizar mi composición corporal",
          "Identificación de mis fortalezas y plan detallado para corregir mis debilidades",
          "Estrategia completa para optimizar mi recuperación y prevención de lesiones",
          "Análisis de consistencia entre mis objetivos, nutrición y entrenamientos",
          "Plan de periodización detallado para los próximos 3 meses basado en mis datos"
        ];
      case 'ar':
        return [
          "تحليل شامل لتقدمي مع توصيات مفصلة للأسابيع الأربعة القادمة",
          "تقييم عميق لتغذيتي: التوازن والتوقيت والتحسينات المحتملة",
          "خطة تحسين تمارينى بناءً على أدائي الحالي",
          "تحليل مقاييسي الجسدية واستراتيجيات لتحسين تركيب جسمي",
          "تحديد نقاط قوتي وخطة مفصلة لتصحيح نقاط ضعفي",
          "استراتيجية شاملة لتحسين تعافيي ومنع الإصابات",
          "تحليل الاتساق بين أهدافي وتغذيتي وتمارينى",
          "خطة دورية مفصلة للأشهر الثلاثة القادمة بناءً على بياناتي"
        ];
      case 'fr':
        return [
          "Analyse complète de mes progrès avec recommandations détaillées pour les 4 prochaines semaines",
          "Évaluation approfondie de ma nutrition : équilibre, timing, et optimisations possibles",
          "Plan d'amélioration de mes entraînements basé sur mes performances actuelles",
          "Analyse de mes métriques corporelles et stratégies pour optimiser ma composition corporelle",
          "Identification de mes points forts et plan détaillé pour corriger mes faiblesses",
          "Stratégie complète d'optimisation de ma récupération et prévention des blessures",
          "Analyse de la cohérence entre mes objectifs, mon alimentation et mes entraînements",
          "Plan de périodisation détaillé pour les 3 prochains mois basé sur mes données"
        ];
      case 'de':
        return [
          "Vollständige Analyse meines Fortschritts mit detaillierten Empfehlungen für die nächsten 4 Wochen",
          "Tiefgreifende Bewertung meiner Ernährung: Balance, Timing und mögliche Optimierungen",
          "Verbesserungsplan für meine Workouts basierend auf meiner aktuellen Leistung",
          "Analyse meiner Körpermetriken und Strategien zur Optimierung meiner Körperzusammensetzung",
          "Identifikation meiner Stärken und detaillierter Plan zur Korrektur meiner Schwächen",
          "Vollständige Strategie zur Optimierung meiner Erholung und Verletzungsprävention",
          "Analyse der Konsistenz zwischen meinen Zielen, Ernährung und Training",
          "Detaillierter Periodisierungsplan für die nächsten 3 Monate basierend auf meinen Daten"
        ];
      default: // English
        return [
          "Complete analysis of my progress with detailed recommendations for the next 4 weeks",
          "In-depth evaluation of my nutrition: balance, timing, and possible optimizations",
          "Improvement plan for my workouts based on my current performance",
          "Analysis of my body metrics and strategies to optimize my body composition",
          "Identification of my strengths and detailed plan to correct my weaknesses",
          "Complete strategy for optimizing my recovery and injury prevention",
          "Analysis of consistency between my goals, nutrition and training",
          "Detailed periodization plan for the next 3 months based on my data"
        ];
    }
  };

  const suggestedQuestions = getSuggestedQuestions();

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">{t('analysis.title')}</h2>
          <p className="text-gray-400 text-sm mt-1">
            {t('analysis.subtitle')}
          </p>
        </div>
        <Brain className="h-8 w-8 text-orange-500" />
      </div>

      {/* Data Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-900 rounded-lg p-4 border border-gray-800">
          <div className="flex items-center gap-2 mb-2">
            <Dumbbell className="h-5 w-5 text-orange-500" />
            <h3 className="text-sm font-medium text-gray-400">{t('analysis.workouts')}</h3>
          </div>
          <p className="text-2xl font-bold text-white">{stats.workouts}</p>
          <p className="text-xs text-gray-500">{t('analysis.sessions_recorded')}</p>
        </div>

        <div className="bg-gray-900 rounded-lg p-4 border border-gray-800">
          <div className="flex items-center gap-2 mb-2">
            <Utensils className="h-5 w-5 text-green-500" />
            <h3 className="text-sm font-medium text-gray-400">{t('analysis.nutrition')}</h3>
          </div>
          <p className="text-2xl font-bold text-white">{stats.nutritionDays}</p>
          <p className="text-xs text-gray-500">{t('analysis.days_tracked')}</p>
        </div>

        <div className="bg-gray-900 rounded-lg p-4 border border-gray-800">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="h-5 w-5 text-blue-500" />
            <h3 className="text-sm font-medium text-gray-400">{t('analysis.metrics')}</h3>
          </div>
          <p className="text-2xl font-bold text-white">{stats.bodyMetrics}</p>
          <p className="text-xs text-gray-500">{t('analysis.measurements_taken')}</p>
        </div>

        <div className="bg-gray-900 rounded-lg p-4 border border-gray-800">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-5 w-5 text-purple-500" />
            <h3 className="text-sm font-medium text-gray-400">{t('analysis.tracking')}</h3>
          </div>
          <p className="text-2xl font-bold text-white">{stats.totalDays}</p>
          <p className="text-xs text-gray-500">{t('analysis.days_of_data')}</p>
        </div>
      </div>

      {/* Analysis Section */}
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <h3 className="text-lg font-medium text-white mb-4">
          {t('analysis.personalized_title')}
        </h3>
        
        {!dataLoaded && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-yellow-500" />
              <p className="text-yellow-400 text-sm">
                {t('analysis.no_data')}
              </p>
            </div>
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              {t('analysis.ask_question')}
            </label>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder={t('analysis.question_placeholder')}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-orange-500 focus:outline-none resize-none"
              rows={4}
              disabled={!dataLoaded}
            />
            <p className="text-xs text-gray-500 mt-1">
              {t('analysis.specific_question')}
            </p>
          </div>

          <button
            onClick={analyzeData}
            disabled={!question.trim() || analyzing || !dataLoaded}
            className={`w-full flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-colors ${
              !question.trim() || analyzing || !dataLoaded
                ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                : 'bg-orange-500 hover:bg-orange-600 text-white'
            }`}
          >
            {analyzing ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                {t('analysis.in_progress')}
              </>
            ) : (
              <>
                <Brain className="h-5 w-5" />
                {t('analysis.launch_analysis')}
              </>
            )}
          </button>
        </div>

        {/* Suggested Questions */}
        {dataLoaded && !analysis && (
          <div className="mt-6">
            <h4 className="text-sm font-medium text-gray-400 mb-3">
              {t('analysis.suggested_questions')}
            </h4>
            <div className="grid grid-cols-1 gap-2">
              {suggestedQuestions.map((suggestedQ, index) => (
                <button
                  key={index}
                  onClick={() => setQuestion(suggestedQ)}
                  className="text-left p-3 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm text-gray-300 hover:text-white transition-colors"
                >
                  {suggestedQ}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Analysis Result */}
        {analysis && (
          <div className="mt-6 p-6 bg-gray-800 rounded-lg border border-gray-700">
            <div className="flex items-center gap-2 mb-4">
              <Brain className="h-5 w-5 text-orange-500" />
              <h4 className="text-lg font-medium text-orange-400">{t('analysis.detailed_title')}</h4>
            </div>
            <div className="prose prose-invert max-w-none">
              <div className="text-gray-300 whitespace-pre-wrap leading-relaxed text-sm">
                {analysis}
              </div>
            </div>
            <div className="flex gap-3 mt-6 pt-4 border-t border-gray-700">
              <button
                onClick={() => {
                  setAnalysis('');
                  setQuestion('');
                }}
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-md text-sm text-white transition-colors"
              >
                {t('analysis.new_analysis')}
              </button>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(analysis);
                }}
                className="px-4 py-2 bg-orange-500 hover:bg-orange-600 rounded-md text-sm text-white transition-colors"
              >
                {t('analysis.copy_analysis')}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DataAnalysis;