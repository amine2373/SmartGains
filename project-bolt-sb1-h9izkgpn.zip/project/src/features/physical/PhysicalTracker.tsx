import React, { useState, useEffect } from 'react';
import { Plus, ChevronDown, ChevronUp, Camera, CalendarDays } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import MetricsChart from './MetricsChart';
import PhotoGallery from './PhotoGallery';
import { BodyMetric, BodyPhoto } from '../../types';
import { getBodyMetrics, saveBodyMetric, getBodyPhotos } from '../../utils/storage';

const PhysicalTracker: React.FC = () => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'metrics' | 'photos'>('metrics');
  const [showAddMetric, setShowAddMetric] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [metrics, setMetrics] = useState<BodyMetric[]>([]);
  const [photos, setPhotos] = useState<BodyPhoto[]>([]);
  const [newMetric, setNewMetric] = useState<Omit<BodyMetric, 'id' | 'date'>>({
    weight: 0,
    bodyFat: 0,
    bmi: 0,
    testosterone: 0
  });
  
  useEffect(() => {
    const loadData = async () => {
      try {
        const [metricsData, photosData] = await Promise.all([
          getBodyMetrics(),
          getBodyPhotos()
        ]);
        setMetrics(metricsData);
        setPhotos(photosData);
      } catch (error) {
        console.error('Error loading physical data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);
  
  const handleAddMetric = async () => {
    setSaving(true);
    try {
      const metric: BodyMetric = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        ...newMetric
      };
      
      await saveBodyMetric(metric);
      setMetrics([...metrics, metric]);
      setShowAddMetric(false);
      setNewMetric({
        weight: 0,
        bodyFat: 0,
        bmi: 0,
        testosterone: 0
      });
    } catch (error) {
      console.error('Error saving metric:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">{t('physical.title')}</h2>
        
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('metrics')}
            className={`px-3 py-1 rounded-md ${
              activeTab === 'metrics'
                ? 'bg-orange-500 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {t('physical.metrics')}
          </button>
          <button
            onClick={() => setActiveTab('photos')}
            className={`px-3 py-1 rounded-md ${
              activeTab === 'photos'
                ? 'bg-orange-500 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {t('physical.photos')}
          </button>
        </div>
      </div>
      
      {activeTab === 'metrics' ? (
        <div className="metrics-section">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-white">{t('physical.body_metrics')}</h3>
            <button
              onClick={() => setShowAddMetric(!showAddMetric)}
              className="flex items-center gap-1 px-3 py-1 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors text-white"
            >
              {showAddMetric ? <ChevronUp className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
              <span>{showAddMetric ? t('common.cancel') : t('physical.add_metric')}</span>
            </button>
          </div>
          
          {showAddMetric && (
            <div className="bg-gray-900 p-4 rounded-lg border border-gray-800 mb-6">
              <h4 className="text-sm font-medium text-gray-300 mb-4">{t('physical.new_measurement')}</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">{t('physical.weight_kg')}</label>
                  <input
                    type="number"
                    value={newMetric.weight || ''}
                    onChange={(e) => setNewMetric({ ...newMetric, weight: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">{t('physical.body_fat_percent')}</label>
                  <input
                    type="number"
                    value={newMetric.bodyFat || ''}
                    onChange={(e) => setNewMetric({ ...newMetric, bodyFat: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">{t('physical.bmi')}</label>
                  <input
                    type="number"
                    value={newMetric.bmi || ''}
                    onChange={(e) => setNewMetric({ ...newMetric, bmi: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">{t('physical.testosterone')}</label>
                  <input
                    type="number"
                    value={newMetric.testosterone || ''}
                    onChange={(e) => setNewMetric({ ...newMetric, testosterone: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
              </div>
              
              <button
                onClick={handleAddMetric}
                disabled={saving}
                className={`w-full px-4 py-2 rounded-md transition-colors text-white flex items-center justify-center gap-2 ${
                  saving 
                    ? 'bg-gray-700 cursor-not-allowed' 
                    : 'bg-orange-500 hover:bg-orange-600'
                }`}
              >
                {saving ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    {t('physical.saving')}
                  </>
                ) : (
                  t('physical.save_measurements')
                )}
              </button>
            </div>
          )}
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
              <h4 className="text-sm font-medium text-gray-400 mb-1">{t('physical.current_weight')}</h4>
              <p className="text-2xl font-bold text-white">
                {metrics.length > 0 ? metrics[metrics.length - 1].weight : '--'} kg
              </p>
            </div>
            
            <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
              <h4 className="text-sm font-medium text-gray-400 mb-1">{t('physical.body_fat')}</h4>
              <p className="text-2xl font-bold text-white">
                {metrics.length > 0 ? metrics[metrics.length - 1].bodyFat : '--'}%
              </p>
            </div>
            
            <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
              <h4 className="text-sm font-medium text-gray-400 mb-1">{t('physical.bmi')}</h4>
              <p className="text-2xl font-bold text-white">
                {metrics.length > 0 ? metrics[metrics.length - 1].bmi : '--'}
              </p>
            </div>
            
            <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
              <h4 className="text-sm font-medium text-gray-400 mb-1">{t('physical.testosterone')}</h4>
              <p className="text-2xl font-bold text-white">
                {metrics.length > 0 ? metrics[metrics.length - 1].testosterone : '--'} ng/dL
              </p>
            </div>
          </div>
          
          <div className="chart-container bg-gray-900 p-4 rounded-lg border border-gray-800">
            <h4 className="text-sm font-medium text-gray-300 mb-4">{t('physical.progress_chart')}</h4>
            <MetricsChart metrics={metrics} />
          </div>
        </div>
      ) : (
        <PhotoGallery photos={photos} />
      )}
    </div>
  );
};

export default PhysicalTracker;