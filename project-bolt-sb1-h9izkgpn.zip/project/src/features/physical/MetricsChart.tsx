import React, { useState } from 'react';
import { BodyMetric } from '../../types';

interface MetricsChartProps {
  metrics: BodyMetric[];
}

const MetricsChart: React.FC<MetricsChartProps> = ({ metrics }) => {
  const [selectedMetric, setSelectedMetric] = useState<'weight' | 'bodyFat' | 'bmi' | 'testosterone'>('weight');
  const [hoveredPoint, setHoveredPoint] = useState<number | null>(null);
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);
  
  if (metrics.length === 0) {
    return (
      <div className="h-48 flex items-center justify-center text-gray-500">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-3 bg-gray-800 rounded-lg flex items-center justify-center">
            <div className="w-8 h-8 border-2 border-gray-600 rounded"></div>
          </div>
          <p className="text-sm">No data available</p>
          <p className="text-xs text-gray-600">Add measurements to see your progress</p>
        </div>
      </div>
    );
  }
  
  // Sort metrics by date
  const sortedMetrics = [...metrics].sort((a, b) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });
  
  // Get values for the selected metric
  const values = sortedMetrics.map(metric => metric[selectedMetric]);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  
  // Calculate tighter Y-axis range for better visibility
  const calculateYAxisRange = () => {
    const dataMin = Math.min(...values);
    const dataMax = Math.max(...values);
    
    // If all values are the same, create a small range around the value
    if (dataMin === dataMax) {
      return {
        min: Math.max(0, dataMin - 5),
        max: dataMax + 5
      };
    }
    
    // Create a tighter range: 5 units below min and 5 units above max
    const paddedMin = Math.max(0, dataMin - 5);
    const paddedMax = dataMax + 5;
    
    return { min: paddedMin, max: paddedMax };
  };
  
  const { min: paddedMin, max: paddedMax } = calculateYAxisRange();
  const paddedRange = paddedMax - paddedMin;
  
  // Chart dimensions
  const chartWidth = 100;
  const chartHeight = 100;
  
  // Format date labels
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };
  
  // Format full date for tooltip
  const formatFullDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };
  
  // Generate points for the line chart
  const generatePoints = () => {
    if (sortedMetrics.length === 1) {
      const y = chartHeight - ((sortedMetrics[0][selectedMetric] - paddedMin) / paddedRange) * chartHeight;
      return `50,${y}`;
    }
    
    return sortedMetrics.map((metric, index) => {
      const x = (index / (sortedMetrics.length - 1)) * chartWidth;
      const y = chartHeight - ((metric[selectedMetric] - paddedMin) / paddedRange) * chartHeight;
      return `${x},${y}`;
    }).join(' ');
  };
  
  // Generate individual point coordinates
  const generatePointCoordinates = () => {
    if (sortedMetrics.length === 1) {
      const y = chartHeight - ((sortedMetrics[0][selectedMetric] - paddedMin) / paddedRange) * chartHeight;
      return [{ x: 50, y }];
    }
    
    return sortedMetrics.map((metric, index) => {
      const x = (index / (sortedMetrics.length - 1)) * chartWidth;
      const y = chartHeight - ((metric[selectedMetric] - paddedMin) / paddedRange) * chartHeight;
      return { x, y };
    });
  };
  
  const points = generatePoints();
  const pointCoordinates = generatePointCoordinates();
  
  // Generate Y-axis labels with the new tighter range
  const generateYLabels = () => {
    const labels = [];
    const numIntervals = 4; // 0, 1, 2, 3 (4 labels total)
    
    for (let i = 0; i < numIntervals; i++) {
      const value = paddedMax - (i * paddedRange / (numIntervals - 1));
      // Round to 1 decimal place for better precision
      labels.push(value.toFixed(1));
    }
    return labels;
  };
  
  const yLabels = generateYLabels();
  
  // Get unit for selected metric
  const getUnit = () => {
    switch (selectedMetric) {
      case 'weight': return 'kg';
      case 'bodyFat': return '%';
      case 'bmi': return '';
      case 'testosterone': return 'ng/dL';
      default: return '';
    }
  };
  
  // Handle point click
  const handlePointClick = (index: number) => {
    setSelectedPoint(selectedPoint === index ? null : index);
  };
  
  return (
    <div className="space-y-4">
      {/* Metric selector */}
      <div className="flex justify-between items-center">
        <div className="flex space-x-1">
          {[
            { key: 'weight', label: 'Weight' },
            { key: 'bodyFat', label: 'Body Fat' },
            { key: 'bmi', label: 'BMI' },
            { key: 'testosterone', label: 'Testosterone' }
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => {
                setSelectedMetric(key as any);
                setSelectedPoint(null);
                setHoveredPoint(null);
              }}
              className={`px-2 py-1 text-xs rounded transition-colors ${
                selectedMetric === key
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-300'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        
        {/* Current value display */}
        <div className="text-right">
          <div className="text-lg font-semibold text-white">
            {sortedMetrics[sortedMetrics.length - 1][selectedMetric]}
            <span className="text-xs text-gray-400 ml-1">{getUnit()}</span>
          </div>
          <div className="text-xs text-gray-500">Current</div>
        </div>
      </div>
      
      {/* Chart container */}
      <div className="relative bg-gray-800/30 rounded-lg p-4">
        {/* Y-axis labels */}
        <div className="absolute left-0 top-4 bottom-6 flex flex-col justify-between text-xs text-gray-500 pr-2">
          {yLabels.map((label, index) => (
            <span key={index} className="leading-none font-mono">{label}</span>
          ))}
        </div>
        
        {/* Chart area */}
        <div className="ml-6 relative">
          {/* Background grid */}
          <div className="absolute inset-0 h-28">
            {[0, 1, 2, 3].map(i => (
              <div 
                key={i}
                className="absolute w-full border-t border-gray-700/20"
                style={{ top: `${(i / 3) * 100}%` }}
              />
            ))}
          </div>
          
          {/* SVG Chart */}
          <svg 
            className="w-full h-28 relative z-10" 
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            preserveAspectRatio="none"
          >
            {/* Chart line */}
            {sortedMetrics.length > 1 && (
              <polyline
                points={points}
                fill="none"
                stroke="#f97316"
                strokeWidth="1"
                strokeLinecap="round"
                strokeLinejoin="round"
                vectorEffect="non-scaling-stroke"
              />
            )}
            
            {/* Interactive points */}
            {pointCoordinates.map((point, index) => (
              <g key={index}>
                {/* Invisible larger circle for easier clicking */}
                <circle
                  cx={point.x}
                  cy={point.y}
                  r="8"
                  fill="transparent"
                  className="cursor-pointer"
                  onClick={() => handlePointClick(index)}
                  onMouseEnter={() => setHoveredPoint(index)}
                  onMouseLeave={() => setHoveredPoint(null)}
                />
                
                {/* Visible point */}
                <circle
                  cx={point.x}
                  cy={point.y}
                  r={hoveredPoint === index || selectedPoint === index ? "3" : "2"}
                  fill={selectedPoint === index ? "#ffffff" : "#f97316"}
                  stroke={selectedPoint === index ? "#f97316" : "#ffffff"}
                  strokeWidth={selectedPoint === index ? "2" : "1"}
                  className="cursor-pointer transition-all duration-200"
                  vectorEffect="non-scaling-stroke"
                  onClick={() => handlePointClick(index)}
                  onMouseEnter={() => setHoveredPoint(index)}
                  onMouseLeave={() => setHoveredPoint(null)}
                />
              </g>
            ))}
          </svg>
          
          {/* X-axis labels */}
          <div className="mt-2 flex justify-between text-xs text-gray-500 font-mono">
            {sortedMetrics.length === 1 ? (
              <div className="w-full text-center">
                {formatDate(sortedMetrics[0].date)}
              </div>
            ) : (
              sortedMetrics.map((metric, index) => (
                <span key={index} className="flex-1 text-center">
                  {formatDate(metric.date)}
                </span>
              ))
            )}
          </div>
        </div>
        
        {/* Point details tooltip */}
        {selectedPoint !== null && (
          <div className="absolute top-4 right-4 bg-gray-900 border border-gray-700 rounded-lg p-3 shadow-lg z-20 min-w-48">
            <div className="text-sm">
              <div className="text-orange-400 font-medium mb-2">
                {formatFullDate(sortedMetrics[selectedPoint].date)}
              </div>
              
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-400">Weight:</span>
                  <span className="text-white font-medium">{sortedMetrics[selectedPoint].weight} kg</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Body Fat:</span>
                  <span className="text-white font-medium">{sortedMetrics[selectedPoint].bodyFat}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">BMI:</span>
                  <span className="text-white font-medium">{sortedMetrics[selectedPoint].bmi}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Testosterone:</span>
                  <span className="text-white font-medium">{sortedMetrics[selectedPoint].testosterone} ng/dL</span>
                </div>
              </div>
              
              <div className="mt-2 pt-2 border-t border-gray-700">
                <div className="text-orange-400 font-medium">
                  {selectedMetric.charAt(0).toUpperCase() + selectedMetric.slice(1)}: {sortedMetrics[selectedPoint][selectedMetric]}{getUnit()}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Progress summary */}
      {sortedMetrics.length > 1 && (
        <div className="flex justify-between items-center text-xs font-mono">
          <div className="text-gray-500">
            {sortedMetrics.length} measurements
          </div>
          <div className="flex items-center space-x-3">
            <div className="text-gray-500">
              Min: <span className="text-white font-semibold">{Math.min(...values).toFixed(1)}</span>
            </div>
            <div className="text-gray-500">
              Max: <span className="text-white font-semibold">{Math.max(...values).toFixed(1)}</span>
            </div>
            <div className="text-gray-500">
              Δ: <span className={`font-semibold ${values[values.length - 1] > values[0] ? 'text-green-400' : 'text-red-400'}`}>
                {values[values.length - 1] > values[0] ? '+' : ''}{(values[values.length - 1] - values[0]).toFixed(1)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MetricsChart;