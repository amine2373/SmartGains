import React, { useState } from 'react';
import { Camera, X, Save, MessageCircle } from 'lucide-react';
import { BodyPhoto } from '../../types';
import { saveBodyPhoto } from '../../utils/storage';

interface PhotoGalleryProps {
  photos: BodyPhoto[];
}

const PhotoGallery: React.FC<PhotoGalleryProps> = ({ photos: initialPhotos }) => {
  const [showAddPhoto, setShowAddPhoto] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [newPhotoNote, setNewPhotoNote] = useState('');
  const [photos, setPhotos] = useState<BodyPhoto[]>(initialPhotos);
  const [viewingPhoto, setViewingPhoto] = useState<BodyPhoto | null>(null);
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setSelectedImage(event.target.result);
      }
    };
    reader.readAsDataURL(file);
  };
  
  const handleSavePhoto = () => {
    if (!selectedImage) return;
    
    const newPhoto: BodyPhoto = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      imageUrl: selectedImage,
      note: newPhotoNote
    };
    
    saveBodyPhoto(newPhoto);
    setPhotos([...photos, newPhoto]);
    setSelectedImage(null);
    setNewPhotoNote('');
    setShowAddPhoto(false);
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-white">Progress Photos</h3>
        <button
          onClick={() => setShowAddPhoto(!showAddPhoto)}
          className="flex items-center gap-1 px-3 py-1 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors text-white"
        >
          {showAddPhoto ? <X className="h-4 w-4" /> : <Camera className="h-4 w-4" />}
          <span>{showAddPhoto ? 'Cancel' : 'Add Photo'}</span>
        </button>
      </div>
      
      {showAddPhoto && (
        <div className="bg-gray-900 p-4 rounded-lg border border-gray-800 mb-6">
          {!selectedImage ? (
            <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center">
              <div className="flex flex-col items-center">
                <Camera className="h-12 w-12 text-gray-500 mb-3" />
                <p className="text-sm text-gray-400 mb-4">Upload a progress photo</p>
                <label className="cursor-pointer bg-orange-500 hover:bg-orange-600 transition-colors px-4 py-2 rounded-md text-white">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                  />
                  Select Image
                </label>
              </div>
            </div>
          ) : (
            <div>
              <div className="relative mb-4">
                <img 
                  src={selectedImage} 
                  alt="Progress" 
                  className="w-full h-64 object-cover rounded-lg" 
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-2 right-2 bg-black bg-opacity-50 rounded-full p-1 text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-400 mb-1">Notes</label>
                <textarea
                  value={newPhotoNote}
                  onChange={(e) => setNewPhotoNote(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:border-orange-500 focus:outline-none"
                  rows={3}
                  placeholder="Add notes about your progress..."
                />
              </div>
              
              <button
                onClick={handleSavePhoto}
                className="w-full flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 transition-colors px-4 py-2 rounded-md text-white"
              >
                <Save className="h-4 w-4" />
                Save Photo
              </button>
            </div>
          )}
        </div>
      )}
      
      {photos.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {photos.map(photo => (
            <div 
              key={photo.id} 
              className="bg-gray-900 rounded-lg overflow-hidden border border-gray-800 cursor-pointer transform transition-transform hover:scale-[1.02]"
              onClick={() => setViewingPhoto(photo)}
            >
              <div className="relative h-48">
                <img 
                  src={photo.imageUrl} 
                  alt="Progress" 
                  className="w-full h-full object-cover" 
                />
                {photo.note && (
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 rounded-full p-1 text-white">
                    <MessageCircle className="h-4 w-4" />
                  </div>
                )}
              </div>
              <div className="p-2">
                <p className="text-sm text-gray-400">
                  {new Date(photo.date).toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-10 text-gray-500">
          <Camera className="h-12 w-12 mx-auto mb-3 text-gray-600" />
          <p>No progress photos yet. Add your first photo to track your progress.</p>
        </div>
      )}
      
      {viewingPhoto && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-2xl w-full border border-gray-800 shadow-lg">
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-white">
                {new Date(viewingPhoto.date).toLocaleDateString('en-US', { 
                  weekday: 'long',
                  month: 'long', 
                  day: 'numeric',
                  year: 'numeric'
                })}
              </h3>
              <button onClick={() => setViewingPhoto(null)} className="text-gray-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-4">
              <img 
                src={viewingPhoto.imageUrl} 
                alt="Progress" 
                className="w-full max-h-[60vh] object-contain rounded-lg mb-4" 
              />
              
              {viewingPhoto.note && (
                <div className="bg-gray-800 p-3 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-300 mb-1">Notes</h4>
                  <p className="text-gray-400">{viewingPhoto.note}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PhotoGallery;