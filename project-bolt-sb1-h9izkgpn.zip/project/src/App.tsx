import React, { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './components/ui/Tabs';
import { Utensils, LineChart, Bot, BarChart3 } from 'lucide-react';
import WorkoutTracker from './features/workout/WorkoutTracker';
import NutritionTracker from './features/nutrition/NutritionTracker';
import PhysicalTracker from './features/physical/PhysicalTracker';
import GymAI from './features/ai/GymAI';
import DataAnalysis from './features/analysis/DataAnalysis';
import Header from './components/Header';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider, useLanguage } from './contexts/LanguageContext';

const AppContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState('workout');
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col">
        <Header />
        
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-md mx-auto px-4">
            <div className="w-20 h-20 bg-orange-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <span className="text-white font-bold text-3xl">SG</span>
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">
              {t('app.welcome')} <span className="text-orange-500">Smart</span>Gains
            </h2>
            <p className="text-gray-400 mb-8">
              {t('app.tagline')}
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-left">
                <div className="w-5 h-5 bg-orange-500 rounded flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-xs">SG</span>
                </div>
                <span className="text-gray-300">{t('app.workout_tracking')}</span>
              </div>
              <div className="flex items-center gap-3 text-left">
                <Utensils className="h-5 w-5 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300">{t('app.nutrition_tracker')}</span>
              </div>
              <div className="flex items-center gap-3 text-left">
                <LineChart className="h-5 w-5 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300">{t('app.progress_analysis')}</span>
              </div>
              <div className="flex items-center gap-3 text-left">
                <Bot className="h-5 w-5 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300">{t('app.personal_ai')}</span>
              </div>
              <div className="flex items-center gap-3 text-left">
                <BarChart3 className="h-5 w-5 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300">{t('app.smart_analysis')}</span>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-8">
              {t('app.sign_in_prompt')}
            </p>
          </div>
        </main>
        
        <footer className="py-4 px-6 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} SmartGains - All rights reserved
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        <Tabs defaultValue="workout" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-5 mb-8">
            <TabsTrigger value="workout" className="flex flex-col items-center gap-1 py-3">
              <div className="w-5 h-5 bg-orange-500 rounded flex items-center justify-center">
                <span className="text-white font-bold text-xs">SG</span>
              </div>
              <span className="text-xs sm:text-sm">{t('nav.workout')}</span>
            </TabsTrigger>
            <TabsTrigger value="nutrition" className="flex flex-col items-center gap-1 py-3">
              <Utensils className="h-5 w-5" />
              <span className="text-xs sm:text-sm">{t('nav.nutrition')}</span>
            </TabsTrigger>
            <TabsTrigger value="track" className="flex flex-col items-center gap-1 py-3">
              <LineChart className="h-5 w-5" />
              <span className="text-xs sm:text-sm">{t('nav.track')}</span>
            </TabsTrigger>
            <TabsTrigger value="analysis" className="flex flex-col items-center gap-1 py-3">
              <BarChart3 className="h-5 w-5" />
              <span className="text-xs sm:text-sm">{t('nav.analysis')}</span>
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex flex-col items-center gap-1 py-3">
              <Bot className="h-5 w-5" />
              <span className="text-xs sm:text-sm">{t('nav.ai')}</span>
            </TabsTrigger>
          </TabsList>
          
          <div className="tab-content-container">
            <TabsContent value="workout" className="mt-0">
              <WorkoutTracker />
            </TabsContent>
            
            <TabsContent value="nutrition" className="mt-0">
              <NutritionTracker />
            </TabsContent>
            
            <TabsContent value="track" className="mt-0">
              <PhysicalTracker />
            </TabsContent>
            
            <TabsContent value="analysis" className="mt-0">
              <DataAnalysis />
            </TabsContent>
            
            <TabsContent value="ai" className="mt-0">
              <GymAI />
            </TabsContent>
          </div>
        </Tabs>
      </main>
      
      <footer className="py-4 px-6 text-center text-sm text-gray-400">
        © {new Date().getFullYear()} SmartGains - All rights reserved
      </footer>
    </div>
  );
};

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;