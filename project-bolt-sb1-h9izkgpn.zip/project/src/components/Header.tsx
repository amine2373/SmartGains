import React, { useState } from 'react';
import { LogOut, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import AuthModal from './auth/AuthModal';
import LanguageSelector from './LanguageSelector';

const Header: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { t } = useLanguage();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleAuthClick = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setShowAuthModal(true);
  };

  const handleLogout = async () => {
    try {
      await logout();
      setShowUserMenu(false);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  return (
    <>
      <header className="bg-black border-b border-gray-800 py-4 px-6">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">SG</span>
            </div>
            <h1 className="text-xl font-bold text-white">
              <span className="text-orange-500">Smart</span>Gains
            </h1>
          </div>
          
          <div className="flex items-center gap-3">
            <LanguageSelector />
            
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 px-3 py-2 rounded-md text-white hover:bg-gray-800 transition-colors"
                >
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-sm font-medium">
                    {currentUser.displayName || currentUser.email?.split('@')[0]}
                  </span>
                </button>
                
                {showUserMenu && (
                  <div className="absolute right-0 top-full mt-2 w-48 bg-gray-900 border border-gray-800 rounded-lg shadow-lg z-50">
                    <div className="p-3 border-b border-gray-800">
                      <p className="text-sm text-gray-400">{t('auth.signed_in_as')}</p>
                      <p className="text-sm text-white font-medium truncate">
                        {currentUser.email}
                      </p>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-2 px-3 py-2 text-left text-red-400 hover:bg-gray-800 transition-colors"
                    >
                      <LogOut className="h-4 w-4" />
                      {t('auth.sign_out')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button 
                onClick={() => handleAuthClick('login')}
                className="text-sm px-3 py-1 rounded-md text-white hover:bg-gray-800 transition-colors"
              >
                {t('auth.sign_in')}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Click outside to close user menu */}
      {showUserMenu && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowUserMenu(false)}
        />
      )}

      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        initialMode={authMode}
      />
    </>
  );
};

export default Header;