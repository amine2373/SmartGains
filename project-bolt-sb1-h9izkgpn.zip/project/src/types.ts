// Exercise and Workout types
export interface ExerciseSet {
  reps: number;
  weight: number;
}

export interface Exercise {
  id: string;
  name: string;
  sets: ExerciseSet[];
}

export interface Workout {
  id: string;
  date: string;
  name: string;
  exercises: Exercise[];
}

// Nutrition types
export interface Food {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  photoUrl?: string;
}

export interface Meal {
  id: string;
  type: string;
  foods: Food[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
}

export interface NutritionDay {
  id: string;
  date: string;
  meals: Meal[];
}

// Body tracking types
export interface BodyMetric {
  id: string;
  date: string;
  weight: number;
  bodyFat: number;
  bmi: number;
  testosterone: number;
}

export interface BodyPhoto {
  id: string;
  date: string;
  imageUrl: string;
  note?: string;
}

// AI Assistant types
export interface AIMessage {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: string;
}

export interface AIConversation {
  id: string;
  title: string;
  messages: AIMessage[];
  createdAt: string;
}